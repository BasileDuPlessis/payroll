// Planche hebdomadaire « Tableau de bord de la capitalisation agentique ».
// Lit synthese/22-capitalisation-affectation-assets.md (source de vérité), contrôle la
// cohérence grille / assets, calcule les indicateurs et dessine la planche avec la skill
// compose-horizon-deck. Ensuite : graft.py puis verify.sh. Procédure complète :
// synthese/22-prompt-suivi-hebdo-capitalisation.md.
//
// Usage, depuis la racine du dépôt :
//   node synthese/22-tableau-de-bord-capitalisation-deck.js synthese/22-capitalisation-affectation-assets.md ~/.cache/horizon-deck/capitalisation/out/deck
//   --force : générer malgré des incohérences (à éviter)
// Les fichiers produits restent hors du dépôt ; seule la planche finale est copiée dans synthese/.
const fs = require('fs');
const path = require('path');
const REPO = process.env.HORIZON_REPO || path.resolve(__dirname, '..'); // racine du dépôt
const H = require(path.join(REPO, '.claude/skills/compose-horizon-deck/scripts/horizon.js'));
const [mdPath, outBase] = process.argv.slice(2).filter((a) => !a.startsWith('--'));
const FORCE = process.argv.includes('--force');
const md = fs.readFileSync(mdPath, 'utf8');

// ---------- Lecture du Markdown ----------
function table(title) {
  const lines = md.split('\n');
  const start = lines.findIndex((l) => l.trim() === `## ${title}`);
  if (start < 0) throw new Error(`section « ${title} » introuvable`);
  let i = start + 1;
  while (i < lines.length && !lines[i].trim().startsWith('|') && !lines[i].startsWith('## ')) i++;
  if (i >= lines.length || lines[i].startsWith('## ')) return [];
  const cells = (l) => l.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map((c) => c.trim());
  const head = cells(lines[i]);
  const rows = [];
  for (i += 2; i < lines.length && lines[i].trim().startsWith('|'); i++) {
    const c = cells(lines[i]);
    rows.push(Object.fromEntries(head.map((h, k) => [h, c[k] ?? ''])));
  }
  return rows;
}
const CRIT = ['Connaître', 'Produire', 'Accéder', 'Contrôler'];
const NOTE = { '●': 2, '○': 1, '–': 0, '-': 0 };
const edition = (md.match(/Édition en cours : (\d{2}\/\d{2}\/\d{4})/) || [])[1];
if (!edition) throw new Error('ligne « Édition en cours : jj/mm/aaaa » introuvable');

const domaines = table('Domaines').filter((d) => d.Statut === 'Suivi').sort((a, b) => Number(a.Ordre) - Number(b.Ordre));
const codes = domaines.map((d) => d.Code);
const grid = {};
const errors = [];
for (const r of table('Grille')) {
  const code = r.Domaine.split('·')[0].trim();
  const k = CRIT.indexOf(r['Critère']);
  if (!(r.Note in NOTE) || k < 0) { errors.push(`Grille : ligne illisible « ${r.Domaine} / ${r['Critère']} / ${r.Note} »`); continue; }
  (grid[code] = grid[code] || [null, null, null, null])[k] = NOTE[r.Note];
}
for (const c of codes) if (!grid[c] || grid[c].some((v) => v === null)) errors.push(`Grille : ${c} n'a pas ses 4 critères`);
for (const c of Object.keys(grid)) if (!codes.includes(c)) errors.push(`Grille : ${c} n'est pas un domaine suivi`);

// Cohérence : une note > 0 exige un asset dans la case, une note 0 n'en admet aucun
const cell = {};
const put = (d, c, name) => { (cell[`${d}/${c}`] = cell[`${d}/${c}`] || []).push(name); };
for (const a of table('Assets')) {
  if (!a.Domaine) continue;
  put(a.Domaine, a['Critère'], a.Asset);
  (a['Contribue aussi à'] || '').split(',').map((s) => s.trim()).filter((s) => s && s !== '—')
    .forEach((s) => { const [d, c] = s.split('/'); put(d.trim(), (c || '').trim(), `${a.Asset} (contribue)`); });
}
for (const c of codes) CRIT.forEach((cr, k) => {
  const n = (cell[`${c}/${cr}`] || []).length, v = grid[c] && grid[c][k];
  if (v > 0 && !n) errors.push(`Cohérence : ${c} / ${cr} noté ${v} sans asset`);
  if (v === 0 && n) errors.push(`Cohérence : ${c} / ${cr} noté 0 avec ${n} asset(s)`);
});
const plan = table("Plan d'action").filter((r) => r.Action);
const hist = table('Historique');

// ---------- Indicateurs ----------
const score = (c) => grid[c].reduce((a, b) => a + b, 0);
const stateOf = (c) => { const s = score(c); return s === 8 ? 'ok' : s >= 4 ? 'partial' : s >= 1 ? 'started' : 'missing'; };
const total = codes.reduce((a, c) => a + score(c), 0), cible = codes.length * 8, pct = Math.round((100 * total) / cible);
const counts = { ok: 0, partial: 0, started: 0, missing: 0 };
codes.forEach((c) => counts[stateOf(c)]++);
const scoresStr = codes.map((c) => `${c} ${score(c)}`).join(' · ');

// Évolution à périmètre constant, par rapport à la dernière édition antérieure
const prev = [...hist].reverse().find((h) => h['Édition'] !== edition);
let evolution = 'Première édition du suivi';
if (prev) {
  const ps = Object.fromEntries((prev.Scores || '').split('·').map((s) => s.trim().split(/\s+/)).filter((x) => x.length === 2).map(([c, v]) => [c, Number(v)]));
  const common = codes.filter((c) => c in ps);
  const d = common.reduce((a, c) => a + score(c) - ps[c], 0);
  const added = codes.filter((c) => !(c in ps)), removed = Object.keys(ps).filter((c) => !codes.includes(c));
  const name = (c) => (domaines.find((x) => x.Code === c) || {}).Domaine || ({ DG: 'Digital' }[c] || c);
  evolution = `${d === 0 ? 'stable' : (d > 0 ? '+' : '') + d + ' point' + (Math.abs(d) > 1 ? 's' : '')} à périmètre constant depuis le ${prev['Édition']}`;
  if (added.length || removed.length) {
    evolution += ' · périmètre : ' + [added.length ? `${added.map(name).join(', ')} ajouté${added.length > 1 ? 's' : ''}` : '',
      removed.length ? `${removed.map(name).join(', ')} retiré${removed.length > 1 ? 's' : ''}` : ''].filter(Boolean).join(', ');
  }
}

console.log(`édition ${edition} · ${total}/${cible} = ${pct} % · ${counts.ok} couverts, ${counts.partial} partiels, ${counts.started} amorcés, ${counts.missing} non couverts`);
console.log(`évolution : ${evolution}`);
console.log(`ligne d'historique proposée : | ${edition} | ${codes.length} | ${total} | ${cible} | ${pct} % | ${counts.ok} | ${counts.partial} | ${counts.started} | ${counts.missing} | ${scoresStr} | … |`);
if (errors.length) {
  console.error('INCOHÉRENCES :\n  ' + errors.join('\n  '));
  if (!FORCE) process.exit(1);
}

// ---------- Planche ----------
const { C } = H;
const d = H.deck();
const plural = (n, s) => `${n} ${s}${n > 1 && s !== 'non couvert' ? 's' : ''}`;
const TITLE = `Capitalisation agentique : ${pct} % de la cible atteinte, ${counts.ok} domaine${counts.ok > 1 ? 's' : ''} sur ${codes.length} couverts`;
const DEF = [
  ["Ce que l'agent sait du domaine", 'pratiques, conventions, patterns'],
  ["Ce que l'agent sait faire", 'skills, customisations BMAD'],
  ["Ce que l'agent peut voir et atteindre", 'serveurs MCP'],
  ["Ce qui l'empêche de se tromper", 'hooks, tests, revues'],
];

d.free({ title: TITLE }, (k) => {
  const L = 0.4, W = 12.53;
  k.pitch("Ce qu'une équipe apprend une fois, tous les agents l'appliquent ensuite à chaque feature : la capitalisation transforme l'expertise rare des socles en vitesse de delivery reproductible.");

  // Bande « Les 4 critères » et case de lecture
  const sy = 1.33, sh = 0.5, gap = 0.12, lw = 2.05, cw = (W - lw - gap * 4) / 4;
  CRIT.forEach((c, i) => {
    const x = L + i * (cw + gap);
    k.R({ x, y: sy, w: cw, h: sh, fill: { color: C.light } });
    k.R({ x, y: sy, w: cw, h: 0.04, fill: { color: C.blue } });
    k.TB(c, { x: x + 0.12, y: sy + 0.08, w: cw - 0.24, h: 0.17, fontSize: 9, color: C.navy, valign: 'middle' });
    k.T(DEF[i][0], { x: x + 0.12, y: sy + 0.25, w: cw - 0.24, h: 0.12, fontSize: 7.5, valign: 'middle' });
    k.T(DEF[i][1], { x: x + 0.12, y: sy + 0.37, w: cw - 0.24, h: 0.11, fontSize: 6.5, color: C.muted, valign: 'middle' });
  });
  const lx = L + 4 * (cw + gap);
  k.s.addShape(k.pres.shapes.RECTANGLE, { x: lx, y: sy, w: lw, h: sh, fill: { color: C.white }, line: { color: C.rule, width: 0.75 } });
  k.TB('Lecture', { x: lx + 0.12, y: sy + 0.06, w: lw - 0.24, h: 0.16, fontSize: 8, color: C.navy, valign: 'middle' });
  [[2, 'outillé'], [1, 'partiel'], [0, 'absent']].forEach(([v, lab], i) => {
    const ix = lx + 0.12 + i * 0.64, iy = sy + 0.3;
    k.dot(v, ix + 0.07, iy + 0.06, 0.11);
    k.T(lab, { x: ix + 0.2, y: iy - 0.02, w: 0.44, h: 0.16, fontSize: 7, valign: 'middle' });
  });

  // Grille : hauteur de ligne ajustée au nombre de domaines, pour accueillir de nouveaux SI
  const MY = 1.97, MEND = 6.08, HH = 0.26, GH = 0.17;
  const families = [];
  domaines.forEach((dm) => { const f = families.find((x) => x.name === dm.Famille); f ? f.codes.push(dm.Code) : families.push({ name: dm.Famille, codes: [dm.Code] }); });
  const RH = Math.min(0.25, (MEND - MY - HH - GH * families.length) / codes.length);
  if (RH < 0.17) console.error(`ATTENTION : ${codes.length} domaines, lignes de ${RH.toFixed(3)} in, la planche devient illisible : envisager deux planches`);
  const fs1 = RH >= 0.21 ? 8.5 : RH >= 0.19 ? 8 : 7.5;
  const col = { dom: [L, 2.15], d: [2.6, 0.85], st: [6.1, 1.05] };
  const MW = col.st[0] + col.st[1] - L;
  k.TB('Domaine', { x: L, y: MY, w: 2, h: HH, fontSize: 8.5, color: C.navy, valign: 'middle' });
  CRIT.forEach((c, i) => k.TB(c, { x: col.d[0] + i * col.d[1], y: MY, w: col.d[1], h: HH, fontSize: 8.5, color: C.navy, align: 'center', valign: 'middle' }));
  k.TB('État', { x: col.st[0], y: MY, w: col.st[1], h: HH, fontSize: 8.5, color: C.navy, align: 'center', valign: 'middle' });
  k.s.addShape(k.pres.shapes.LINE, { x: L, y: MY + HH, w: MW, h: 0, line: { color: C.navy, width: 1 } });
  let y = MY + HH;
  families.forEach((f) => {
    k.TB(f.name.toUpperCase(), { x: L, y: y + 0.02, w: 4, h: GH - 0.02, fontSize: 6.5, color: C.orange, charSpacing: 1, valign: 'middle' });
    y += GH;
    f.codes.forEach((c) => {
      const dm = domaines.find((x) => x.Code === c);
      k.TB(dm.Domaine, { x: L, y, w: col.dom[1], h: RH, fontSize: fs1, valign: 'middle' });
      grid[c].forEach((v, i) => k.dot(v, col.d[0] + i * col.d[1] + col.d[1] / 2, y + RH / 2, Math.min(0.12, RH * 0.5)));
      k.pill(stateOf(c), col.st[0] + 0.06, y + 0.03, col.st[1] - 0.12, RH - 0.06, fs1 >= 8 ? 7 : 6.5);
      y += RH;
      k.s.addShape(k.pres.shapes.LINE, { x: L, y, w: MW, h: 0, line: { color: C.rule, width: 0.5 } });
    });
  });

  // À droite : progression vers la cible, puis cadre « Plan d'action » à remplir par l'équipe
  const PX = 7.75, PW = W + L - PX;
  k.TB('Progression vers la cible', { x: PX, y: MY, w: PW, h: 0.2, fontSize: 9.5, color: C.navy });
  k.TB(`${pct} %`, { x: PX, y: MY + 0.2, w: 1.6, h: 0.5, fontSize: 30, color: C.navy, valign: 'middle' });
  k.meter(PX + 1.7, MY + 0.39, PW - 1.7, 0.15, total / cible);
  k.T(`${total} points sur ${cible} · cible : les ${codes.length} domaines outillés sur les 4 critères`, { x: PX, y: MY + 0.76, w: PW, h: 0.16, fontSize: 7.5, color: C.muted });

  k.T([plural(counts.ok, 'couvert'), plural(counts.partial, 'partiel'), plural(counts.started, 'amorcé'), plural(counts.missing, 'non couvert')].join(' · '),
    { x: PX, y: MY + 0.95, w: PW, h: 0.16, fontSize: 7.5, color: C.muted });
  k.T(`Évolution : ${evolution}`, { x: PX, y: MY + 1.14, w: PW, h: 0.3, fontSize: 7.5, color: C.ink });

  const FY = 3.52, FH = MEND - FY;
  k.s.addShape(k.pres.shapes.RECTANGLE, { x: PX, y: FY, w: PW, h: FH, fill: { color: C.white }, line: { color: C.rule, width: 0.75 } });
  k.R({ x: PX, y: FY, w: PW, h: 0.05, fill: { color: C.orange } });
  k.TB("Plan d'action", { x: PX + 0.18, y: FY + 0.15, w: 2.5, h: 0.26, fontSize: 12, color: C.navy, valign: 'middle' });
  k.T(`Semaine du ${edition}`, { x: PX + PW - 2.4, y: FY + 0.15, w: 2.22, h: 0.26, fontSize: 8, color: C.muted, align: 'right', valign: 'middle' });
  const BY = FY + 0.52, BH = FH - 0.65;
  if (plan.length) {
    const items = plan.slice(0, 5).map((r) => [r.Action, [r.Porteur, r['Échéance'], r.Statut].filter((x) => x && x !== '—').join(' · ')]);
    k.T(items.flatMap(([a, m], i) => [
      { text: `${i + 1}   ${a}`, options: { breakLine: true, fontFace: H.FONT.semibold, fontSize: 9 } },
      { text: m ? `      ${m}` : ' ', options: { breakLine: i < items.length - 1, fontSize: 7.5, color: C.muted } },
    ]), { x: PX + 0.18, y: BY, w: PW - 0.36, h: BH, fontSize: 9, paraSpaceAfter: 2 });
    if (plan.length > 5) console.error(`ATTENTION : ${plan.length} actions, seules les 5 premières tiennent dans le cadre`);
  } else {
    // Zone de texte éditable, vide hors consigne, que l'équipe remplit dans PowerPoint
    k.T("À compléter par l'équipe : actions de la semaine, porteur, échéance.", { x: PX + 0.18, y: BY, w: PW - 0.36, h: BH, fontSize: 9, color: C.dash, italic: true });
  }

  k.note('Amélioration continue', "Maintenir les assets fait partie du travail de l'équipe : chaque incident, revue ou correction enrichit un asset existant.");
});

d.save(outBase).then((f) => console.log('écrit', f));
