// Bibliothèque de génération de présentations au format Horizon.
//
// Produit deux fichiers : DECK.pptx (formes libres, via pptxgenjs) et DECK.json (pour chaque
// planche, la mise en page du template et le texte des espaces réservés). graft.py assemble
// ensuite les deux sur le template Horizon.
//
//   const H = require('<skill>/scripts/horizon.js');
//   const d = H.deck();
//   d.cover({ title, subtitle, date });
//   d.free({ title }, (k) => { k.pitch('…'); k.meter(…); });
//   d.save('/tmp/mon-deck/deck');          // écrit deck.pptx et deck.json
//
// Mises en page et clés d'espaces réservés : references/layouts.md.

const fs = require('fs');
const path = require('path');
const os = require('os');

const DEPS = process.env.HORIZON_DECK_DEPS || path.join(os.homedir(), '.cache', 'horizon-deck');
let PptxGenJS;
try {
  PptxGenJS = require(path.join(DEPS, 'node_modules', 'pptxgenjs'));
} catch (e) {
  throw new Error(`pptxgenjs introuvable dans ${DEPS} : lancer scripts/setup.sh`);
}

// Charte : thème du template Horizon
const C = {
  navy: '001A70', blue: '1057C8', sky: '1089FF', orange: 'FE5716', orange2: 'FF861D', amber: 'FFB210',
  track: 'DCE6F7', grey3: 'E3E6EC', ink: '1B1F2A', grey: '44546A', muted: '5F6675', rule: 'D9DCE3',
  light: 'F2F4F8', white: 'FFFFFF', dash: 'B8BDC8',
};
const FONT = { regular: 'Work Sans', semibold: 'Work Sans SemiBold', light: 'Work Sans Light' };
// États : la couleur ne porte jamais seule l'information, toujours avec le libellé
const STATUS = {
  ok: { label: 'Couvert', fill: C.navy, text: C.white },
  partial: { label: 'Partiel', fill: C.blue, text: C.white },
  started: { label: 'Amorcé', fill: C.amber, text: C.navy },
  missing: { label: 'Non couvert', fill: C.orange, text: C.navy },
};
// Zones sûres, en pouces. Sous y1, le masque place les logos et le numéro de page.
const SAFE = { x0: 0.4, x1: 12.93, w: 12.53, yCompact: 0.8, yStandard: 1.6, y1: 6.46 };

function kit(pres, s) {
  const T = (text, o) => s.addText(text, { fontFace: FONT.regular, margin: 0, valign: 'top', color: C.ink, ...o });
  const TB = (text, o) => T(text, { fontFace: FONT.semibold, ...o });
  const R = (o) => s.addShape(pres.shapes.RECTANGLE, { line: { type: 'none' }, ...o });
  const RR = (o) => s.addShape(pres.shapes.ROUNDED_RECTANGLE, { line: { type: 'none' }, ...o });
  const L = SAFE.x0, W = SAFE.w;
  const k = {
    s, pres, C, FONT, STATUS, SAFE, T, TB, R, RR,
    // Bandeau marine à liseré orange, pour un message ou un pitch
    pitch(text, y = 0.8, h = 0.44, size = 12) {
      R({ x: L, y, w: W, h, fill: { color: C.navy } });
      R({ x: L, y, w: 0.08, h, fill: { color: C.orange } });
      TB(text, { x: L + 0.22, y, w: W - 0.35, h, fontSize: size, color: C.white, valign: 'middle' });
    },
    // Bandeau gris clair à liseré orange, en bas de planche
    note(label, text, y = 6.18, h = 0.27) {
      R({ x: L, y, w: W, h, fill: { color: C.light } });
      R({ x: L, y, w: 0.08, h, fill: { color: C.orange } });
      T([{ text: `${label}   `, options: { fontFace: FONT.semibold, color: C.navy } }, { text }],
        { x: L + 0.22, y, w: W - 0.35, h, fontSize: 8, valign: 'middle' });
    },
    // Intertitre de bloc avec filet orange
    head(text, x, y, w) {
      TB(text, { x, y, w, h: 0.2, fontSize: 9.5, color: C.navy });
      s.addShape(pres.shapes.LINE, { x, y: y + 0.23, w: 0.45, h: 0, line: { color: C.orange, width: 2 } });
    },
    // Jauge : remplissage bleu sur fond bleu très clair
    meter(x, y, w, h, frac) {
      RR({ x, y, w, h, rectRadius: h / 2, fill: { color: C.track } });
      RR({ x, y, w: Math.max(w * Math.min(Math.max(frac, 0), 1), h), h, rectRadius: h / 2, fill: { color: C.blue } });
    },
    // Tuile chiffre : libellé, valeur, précision
    stat(x, y, w, h, label, value, sub) {
      s.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: C.white }, line: { color: C.rule, width: 0.75 } });
      TB(label, { x: x + 0.15, y: y + 0.08, w: w - 0.3, h: 0.17, fontSize: 8.5, color: C.grey });
      TB(value, { x: x + 0.15, y: y + 0.26, w: w - 0.3, h: 0.42, fontSize: 26, color: C.navy });
      if (sub) T(sub, { x: x + 0.15, y: y + h - 0.26, w: w - 0.3, h: 0.2, fontSize: 7, color: C.muted });
    },
    // Carte à filet bleu en tête
    card(x, y, w, h, title, body) {
      s.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: C.white }, line: { color: C.rule, width: 0.75 } });
      R({ x, y, w, h: 0.06, fill: { color: C.blue } });
      TB(title, { x: x + 0.18, y: y + 0.17, w: w - 0.36, h: 0.26, fontSize: 12, color: C.navy });
      if (body) T(body, { x: x + 0.18, y: y + 0.5, w: w - 0.36, h: h - 0.65, fontSize: 9 });
    },
    // Pastille d'état avec son libellé
    pill(status, x, y, w, h, size = 7) {
      const st = STATUS[status];
      RR({ x, y, w, h, rectRadius: 0.06, fill: { color: st.fill } });
      TB(st.label, { x, y, w, h, fontSize: size, color: st.text, align: 'center', valign: 'middle' });
    },
    // Marque 2 / 1 / 0 : rond plein, rond vide, tiret
    dot(v, cx, cy, d = 0.12) {
      if (v === 2) s.addShape(pres.shapes.OVAL, { x: cx - d / 2, y: cy - d / 2, w: d, h: d, fill: { color: C.blue }, line: { color: C.blue, width: 1 } });
      else if (v === 1) s.addShape(pres.shapes.OVAL, { x: cx - d / 2 + 0.006, y: cy - d / 2 + 0.006, w: d - 0.012, h: d - 0.012, fill: { color: C.white }, line: { color: C.blue, width: 1.5 } });
      else s.addShape(pres.shapes.LINE, { x: cx - 0.055, y: cy, w: 0.11, h: 0, line: { color: C.dash, width: 1.5 } });
    },
    // Barre segmentée : chaque valeur 0 / 1 / 2 remplit son segment à 0, 50 ou 100 %
    segbar(x, y, w, h, values, color = C.blue, track = C.grey3) {
      const gap = 0.05, sw = (w - gap * (values.length - 1)) / values.length;
      values.forEach((v, i) => {
        const sx = x + i * (sw + gap);
        R({ x: sx, y, w: sw, h, fill: { color: track } });
        if (v > 0) R({ x: sx, y, w: (sw * Math.min(v, 2)) / 2, h, fill: { color } });
      });
    },
    // Liste numérotée en orange, une ligne par élément
    numbered(items, x, y, w, size = 8.5, lh = 0.2) {
      items.forEach((t, i) => {
        TB(String(i + 1), { x, y: y + i * lh, w: 0.18, h: lh, fontSize: size, color: C.orange, valign: 'middle' });
        T(t, { x: x + 0.21, y: y + i * lh, w: w - 0.21, h: lh, fontSize: size, valign: 'middle' });
      });
    },
    // Puces : paragraphes avec retrait suspendu
    bullets(items, x, y, w, h, size = 8.5) {
      T(items.map((t, i) => ({ text: t, options: { bullet: { indent: 9 }, breakLine: i < items.length - 1 } })),
        { x, y, w, h, fontSize: size, paraSpaceAfter: 3 });
    },
    // Étiquette discrète entre les deux logos (version de travail, variante)
    tag(text) {
      T(text, { x: 4.0, y: 6.93, w: 5.3, h: 0.22, fontSize: 8, color: C.muted, align: 'center', italic: true });
    },
  };
  return k;
}

function deck() {
  const pres = new PptxGenJS();
  pres.layout = 'LAYOUT_WIDE'; // 13,333 × 7,5 in, identique au template
  const spec = { slides: [] };
  const add = (layout, ph = {}, opts = {}) => {
    const s = pres.addSlide();
    spec.slides.push({ layout, ph, compactTitle: !!opts.compactTitle, title: ph.title || ph[11] || '' });
    return kit(pres, s);
  };
  const paras = (body) => (Array.isArray(body) ? body : [body]);
  return {
    pres, C, STATUS, SAFE,
    // Mise en page quelconque, par son nom : voir references/layouts.md
    slide: (layout, ph, opts) => add(layout, ph, opts),
    cover: ({ title, subtitle = '', date = '' }) => add('Diapositive de titre', { 11: title, 12: subtitle, 13: date }),
    section: ({ title, subtitle = '', number = '' }) => add('Titre et sous titre de la partie', { title, subTitle: subtitle, 12: number }),
    // Planche de texte : body est une liste de paragraphes, chaînes ou { text, level }
    content: ({ title, body }) => add('Titre et contenu', { title, 14: paras(body) }),
    // Planche libre : titre compact (20 pt, 0,12 à 0,72 in) et dessin dans la zone sûre
    free: ({ title, compact = true }, draw) => {
      const k = add('Titre et contenu', { title }, { compactTitle: compact });
      if (draw) draw(k);
      return k;
    },
    columns: ({ title, cols }) => {
      const map = { 2: [[18, 20], [22, 21]], 3: [[20, 21], [22, 23], [24, 25]], 4: [[22, 23], [24, 25], [26, 27], [28, 29]] };
      const names = { 2: '2 colonnes', 3: '3 colonnes', 4: '4 colonnes' };
      if (!map[cols.length]) throw new Error('columns : 2, 3 ou 4 colonnes');
      const ph = { title };
      cols.forEach((c, i) => { ph[map[cols.length][i][0]] = c.head; ph[map[cols.length][i][1]] = paras(c.body); });
      return add(names[cols.length], ph);
    },
    quote: ({ text, author = '' }) => add('Citation_full', { title: text, 10: author }),
    end: () => add('Slide de fin', {}),
    // Écrit BASE.pptx et BASE.json
    save: (base) => {
      fs.mkdirSync(path.dirname(base), { recursive: true });
      fs.writeFileSync(`${base}.json`, JSON.stringify(spec, null, 1));
      return pres.writeFile({ fileName: `${base}.pptx` }).then(() => `${base}.pptx`);
    },
  };
}

module.exports = { deck, C, FONT, STATUS, SAFE };
