// Exemple et test de non-régression de la skill : une planche par type.
// node example.js /tmp/horizon-deck-exemple/deck
const H = require('./horizon.js');
const out = process.argv[2] || '/tmp/horizon-deck-exemple/deck';
const d = H.deck();

d.cover({ title: 'Présentation au format Horizon', subtitle: 'Exemple généré par la skill compose-horizon-deck', date: '05/11/2026' });
d.section({ number: '01', title: 'Une partie', subtitle: 'Intercalaire sur la mise en page du template' });
d.content({
  title: 'Planche de texte',
  body: ['Un message par planche, porté par le titre', { text: 'Puce de second niveau', level: 1 }, 'Le texte reprend les styles du template, **gras** compris'],
});
d.columns({
  title: 'Trois colonnes',
  cols: [
    { head: 'Constat', body: ['Ce qui est observé'] },
    { head: 'Hypothèse', body: ['Ce qui reste à confirmer'] },
    { head: 'Décision', body: ['Ce qui est attendu, et de qui'] },
  ],
});
d.free({ title: 'Planche libre : 70 % de la cible atteinte' }, (k) => {
  const { C, SAFE } = k;
  k.pitch('Bandeau de message : une phrase forte, sur deux lignes au plus.');
  k.stat(SAFE.x0, 1.4, 3.0, 1.0, 'Progression vers la cible', '70 %', '78 points sur 112');
  k.meter(SAFE.x0 + 3.2, 1.85, 5.6, 0.16, 0.7);
  k.head('Domaines', SAFE.x0, 2.7, 6);
  [['Domaine A', 'ok', [2, 2, 2, 2]], ['Domaine B', 'partial', [2, 1, 2, 0]], ['Domaine C', 'started', [0, 1, 0, 1]], ['Domaine D', 'missing', [0, 0, 0, 0]]]
    .forEach(([n, st, v], i) => {
      const y = 3.05 + i * 0.3;
      k.TB(n, { x: SAFE.x0, y, w: 1.8, h: 0.24, fontSize: 9, valign: 'middle' });
      k.segbar(2.3, y + 0.06, 3.6, 0.12, v, k.STATUS[st].fill);
      k.pill(st, 6.1, y + 0.02, 0.95, 0.2);
    });
  k.head('Priorités', 8.6, 2.7, 4.3);
  k.numbered(['Premier sujet', 'Deuxième sujet', 'Troisième sujet'], 8.6, 3.05, 4.3);
  k.card(8.6, 3.85, 4.33, 1.4, 'Carte', 'Un bloc de texte court dans une carte à filet bleu.');
  k.note('À retenir', 'Bandeau du bas, au-dessus de la zone des logos.');
  k.tag('Version de travail');
});
d.quote({ text: 'Une citation pleine page.', author: 'Nom de l’auteur' });
d.end();
d.save(out).then((f) => console.log('écrit', f));
