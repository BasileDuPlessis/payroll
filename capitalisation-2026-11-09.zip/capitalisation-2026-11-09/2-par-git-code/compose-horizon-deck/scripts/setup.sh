#!/bin/zsh
# Installe pptxgenjs hors du dépôt, dans ~/.cache/horizon-deck (ou $HORIZON_DECK_DEPS).
set -e
DEPS="${HORIZON_DECK_DEPS:-$HOME/.cache/horizon-deck}"
if [[ -d "$DEPS/node_modules/pptxgenjs" ]]; then
  echo "pptxgenjs déjà présent dans $DEPS"
  exit 0
fi
mkdir -p "$DEPS"
cd "$DEPS"
[[ -f package.json ]] || npm init -y >/dev/null
npm install pptxgenjs@4.0.1 --silent
echo "pptxgenjs installé dans $DEPS"
