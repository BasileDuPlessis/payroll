"""Assemble une présentation au format Horizon à partir du template et d'un DECK.pptx/DECK.json
produits par horizon.js.

Pour chaque planche : la mise en page du template désignée par son nom, les espaces réservés
remplis avec le texte de DECK.json (styles du template conservés), puis les formes libres de
DECK.pptx (images et liens compris).

Corrige les pièges connus du template : planches d'exemple retirées avec leurs déclarations de
type (un doublon déclenche la réparation de PowerPoint), ouverture en mode masque, miniature
périmée, mises en page inutilisées et leurs photos (≈ 7 Mo). L'étiquette de sensibilité EDF
« C1 Interne » du template est conservée.

Usage : python3 -I graft.py TEMPLATE.pptx DECK.pptx DECK.json SORTIE.pptx [options]
  --sorter        ouvrir en trieuse de diapositives (planches côte à côte), sinon en vue normale
  --keep-layouts  garder les 26 mises en page du template (fichier plus lourd)
  --compress      recompresser en JPEG les photos de plus de 400 Ko des mises en page gardées (macOS, sips)
"""
import json
import os
import posixpath
import re
import subprocess
import sys
import tempfile
import uuid
import zipfile
from xml.sax.saxutils import escape

args = [a for a in sys.argv[1:] if not a.startswith('--')]
flags = {a for a in sys.argv[1:] if a.startswith('--')}
tpl_path, gen_path, spec_path, out_path = args[:4]
EMU = 914400
NS_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
CT_SLIDE = 'application/vnd.openxmlformats-officedocument.presentationml.slide+xml'
CT_IMG = {'png': 'image/png', 'jpeg': 'image/jpeg', 'jpg': 'image/jpeg', 'gif': 'image/gif', 'svg': 'image/svg+xml',
          'emf': 'image/x-emf', 'wmf': 'image/x-wmf', 'bmp': 'image/bmp', 'tiff': 'image/tiff'}
inch = lambda v: int(round(v * EMU))

spec = json.load(open(spec_path, encoding='utf-8'))
with zipfile.ZipFile(tpl_path) as z:
    parts = {n: z.read(n) for n in z.namelist()}
gen = zipfile.ZipFile(gen_path)

# Mises en page du template, par nom
LAYOUTS = {}
for n in parts:
    if re.match(r'ppt/slideLayouts/slideLayout\d+\.xml$', n):
        m = re.search(rb'<p:cSld name="([^"]*)"', parts[n])
        LAYOUTS[m.group(1).decode('utf-8')] = n


def rels_of(part):
    d, b = posixpath.split(part)
    return posixpath.join(d, '_rels', b + '.rels')


def layout_ph(layout_xml, key):
    """Retourne (type, idx) de l'espace réservé désigné par key dans la mise en page."""
    for b in re.findall(r'<p:sp>.*?</p:sp>', layout_xml, re.S):
        ph = re.search(r'<p:ph\b([^>]*?)/?>', b)
        if not ph:
            continue
        typ = (re.search(r'type="(\w+)"', ph.group(1)) or [None, 'body'])[1]
        idx = (re.search(r'idx="(\d+)"', ph.group(1)) or [None, None])[1]
        if key == 'title' and typ in ('title', 'ctrTitle'):
            return typ, idx
        if key == 'subTitle' and typ == 'subTitle':
            return typ, idx
        if str(key) == idx and typ not in ('pic',):
            return typ, idx
    raise SystemExit(f'espace réservé « {key} » absent de la mise en page')


def runs(text):
    """Texte avec **gras** minimal."""
    out = []
    for i, chunk in enumerate(re.split(r'\*\*', text)):
        if chunk:
            b = ' b="1"' if i % 2 else ''
            out.append(f'<a:r><a:rPr lang="fr-FR"{b} dirty="0"/><a:t>{escape(chunk)}</a:t></a:r>')
    return ''.join(out) or '<a:endParaRPr lang="fr-FR" dirty="0"/>'


def paragraphs(value, compact=False):
    items = value if isinstance(value, list) else [value]
    out = []
    for it in items:
        text, level = (it.get('text', ''), int(it.get('level', 0))) if isinstance(it, dict) else (str(it), 0)
        for line in text.split('\n'):
            ppr = '<a:pPr marL="0"/>' if compact else (f'<a:pPr lvl="{level}"/>' if level else '')
            r = runs(line).replace('dirty="0"/>', 'sz="2000" dirty="0"/>') if compact else runs(line)
            out.append(f'<a:p>{ppr}{r}</a:p>')
    return ''.join(out)


def ph_shape(sid, typ, idx, value, compact):
    idx_attr = f' idx="{idx}"' if idx is not None else ''
    if compact:
        sppr = f'<p:spPr><a:xfrm><a:off x="{inch(0.4)}" y="{inch(0.12)}"/><a:ext cx="{inch(12.53)}" cy="{inch(0.6)}"/></a:xfrm></p:spPr>'
        body = '<a:bodyPr lIns="0" rIns="0" anchor="ctr"><a:normAutofit/></a:bodyPr>'
    else:
        sppr, body = '<p:spPr/>', '<a:bodyPr/>'
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="Espace réservé {sid}"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr>'
            f'<p:nvPr><p:ph type="{typ}"{idx_attr}/></p:nvPr></p:nvSpPr>{sppr}'
            f'<p:txBody>{body}<a:lstStyle/>{paragraphs(value, compact)}</p:txBody></p:sp>')


# 1. Retrait des planches d'exemple
for n in [n for n in parts if n.startswith(('ppt/slides/', 'ppt/notesSlides/', 'ppt/changesInfos/', 'ppt/comments/'))]:
    del parts[n]

used_layouts, new_slides, media_count = set(), [], 0
for i, sl in enumerate(spec['slides'], start=1):
    lname = sl['layout']
    if lname not in LAYOUTS:
        raise SystemExit(f'mise en page inconnue : « {lname} ». Voir references/layouts.md')
    lpart = LAYOUTS[lname]
    used_layouts.add(lpart)
    lxml = parts[lpart].decode('utf-8')

    src = gen.read(f'ppt/slides/slide{i}.xml').decode('utf-8')
    inner = src.split('</p:grpSpPr>', 1)[1].rsplit('</p:spTree>', 1)[0]
    rel_xml = [f'<Relationship Id="rIdLayout" Type="{REL}slideLayout" Target="../slideLayouts/{posixpath.basename(lpart)}"/>']
    grels = gen.read(f'ppt/slides/_rels/slide{i}.xml.rels').decode('utf-8')
    for m in re.finditer(r'<Relationship [^>]*/>', grels):
        tag = m.group(0)
        rid = re.search(r'Id="([^"]+)"', tag).group(1)
        rtype = re.search(r'Type="([^"]+)"', tag).group(1)
        target = re.search(r'Target="([^"]+)"', tag).group(1)
        if rtype.endswith(('/slideLayout', '/notesSlide')):
            continue
        new_id = f'rIdG{rid}'
        inner = re.sub(rf'(r:(?:embed|link|id|pict)=")({re.escape(rid)})(")', rf'\g<1>{new_id}\g<3>', inner)
        if 'TargetMode="External"' in tag:
            rel_xml.append(f'<Relationship Id="{new_id}" Type="{rtype}" Target="{escape(target)}" TargetMode="External"/>')
            continue
        srcp = posixpath.normpath(posixpath.join('ppt/slides', target))
        dst = f'ppt/media/hzd-s{i}-{posixpath.basename(srcp)}'
        parts[dst] = gen.read(srcp)
        media_count += 1
        rel_xml.append(f'<Relationship Id="{new_id}" Type="{rtype}" Target="../media/{posixpath.basename(dst)}"/>')

    counter = iter(range(2, 1_000_000))
    phs = []
    for key, value in sl.get('ph', {}).items():
        if value in ('', None, []):
            continue
        typ, idx = layout_ph(lxml, key)
        compact = sl.get('compactTitle') and key == 'title'
        phs.append(ph_shape(next(counter), typ, idx, value, compact))
    inner = re.sub(r'<p:cNvPr id="\d+"', lambda m: f'<p:cNvPr id="{next(counter)}"', inner)

    name = f'ppt/slides/slide{i}.xml'
    parts[name] = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        f'<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="{NS_R}" '
        'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
        '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
        '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
        + ''.join(phs) + inner +
        '</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>').encode('utf-8')
    parts[rels_of(name)] = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
                            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                            + ''.join(rel_xml) + '</Relationships>').encode('utf-8')
    new_slides.append((255 + i, f'rIdDeck{i}', name, sl.get('title') or lname))

# 2. presentation.xml : liste des planches, une section, relations
pres = parts['ppt/presentation.xml'].decode('utf-8')
assert 'custShowLst' not in pres, 'diaporamas personnalisés : non gérés'
ids = ''.join(f'<p:sldId id="{sid}" r:id="{rid}"/>' for sid, rid, _, _ in new_slides)
pres = re.sub(r'<p:sldIdLst>.*?</p:sldIdLst>', f'<p:sldIdLst>{ids}</p:sldIdLst>', pres, flags=re.S)
sec = ''.join(f'<p14:sldId id="{sid}"/>' for sid, _, _, _ in new_slides)
pres = re.sub(r'<p14:sectionLst\b.*?</p14:sectionLst>',
              '<p14:sectionLst xmlns:p14="http://schemas.microsoft.com/office/powerpoint/2010/main">'
              f'<p14:section name="Présentation" id="{{{str(uuid.uuid5(uuid.NAMESPACE_URL, out_path)).upper()}}}">'
              f'<p14:sldIdLst>{sec}</p14:sldIdLst></p14:section></p14:sectionLst>', pres, flags=re.S)
parts['ppt/presentation.xml'] = pres.encode('utf-8')

prels = parts['ppt/_rels/presentation.xml.rels'].decode('utf-8')
prels = re.sub(r'<Relationship [^>]*Type="[^"]*/(slide|changesInfo)"[^>]*/>', '', prels)
prels = prels.replace('</Relationships>', ''.join(
    f'<Relationship Id="{rid}" Type="{REL}slide" Target="slides/{posixpath.basename(n)}"/>' for _, rid, n, _ in new_slides) + '</Relationships>')
parts['ppt/_rels/presentation.xml.rels'] = prels.encode('utf-8')

# Miniature périmée (couverture du template) et vue d'ouverture
parts['_rels/.rels'] = re.sub(rb'<Relationship [^>]*Type="[^"]*/thumbnail"[^>]*/>', b'', parts['_rels/.rels'])
vp = re.sub(r'\s+lastView="[^"]*"', '', parts['ppt/viewProps.xml'].decode('utf-8'), count=1)
if '--sorter' in flags:
    vp = vp.replace('<p:viewPr ', '<p:viewPr lastView="sldSorterView" ', 1)
parts['ppt/viewProps.xml'] = vp.encode('utf-8')

# 3. Allègement : le masque ne garde que les mises en page utilisées
if '--keep-layouts' not in flags:
    for master in [n for n in parts if re.match(r'ppt/slideMasters/slideMaster\d+\.xml$', n)]:
        mrels = parts[rels_of(master)].decode('utf-8')
        keep_ids = set()
        def keep_rel(m):
            tag = m.group(0)
            tgt = re.search(r'Target="([^"]+)"', tag).group(1)
            if posixpath.normpath(posixpath.join('ppt/slideMasters', tgt)) in used_layouts:
                keep_ids.add(re.search(r'Id="([^"]+)"', tag).group(1))
                return tag
            return ''
        mrels = re.sub(r'<Relationship [^>]*/slideLayout"[^>]*/>', keep_rel, mrels)
        parts[rels_of(master)] = mrels.encode('utf-8')
        mx = parts[master].decode('utf-8')
        kept = ''.join(t for t in re.findall(r'<p:sldLayoutId [^>]*/>', mx) if re.search(r'r:id="([^"]+)"', t).group(1) in keep_ids)
        parts[master] = re.sub(r'<p:sldLayoutIdLst>.*?</p:sldLayoutIdLst>', f'<p:sldLayoutIdLst>{kept}</p:sldLayoutIdLst>', mx, flags=re.S).encode('utf-8')

# 4. Élagage : ne garder que les parties atteignables depuis la racine
reach, todo = set(), ['_rels/.rels']
while todo:
    r = todo.pop()
    if r in reach or r not in parts:
        continue
    reach.add(r)
    base = posixpath.dirname(posixpath.dirname(r))
    for m in re.finditer(rb'<Relationship [^>]*>', parts[r]):
        tag = m.group(0).decode('utf-8')
        if 'TargetMode="External"' in tag:
            continue
        tgt = re.search(r'Target="([^"]*)"', tag).group(1)
        p = tgt.lstrip('/') if tgt.startswith('/') else posixpath.normpath(posixpath.join(base, tgt))
        if p in parts and p not in reach:
            reach.add(p)
            todo.append(rels_of(p))
reach.add('[Content_Types].xml')
dropped = set(parts) - reach
for n in dropped:
    del parts[n]

# 5. Recompression des grosses photos des mises en page gardées
if '--compress' in flags:
    for n in [n for n in list(parts) if n.startswith('ppt/media/') and not n.startswith('ppt/media/hzd-')]:
        ext = n.rsplit('.', 1)[-1].lower()
        if ext not in ('png', 'jpeg', 'jpg', 'tiff') or len(parts[n]) < 400_000:
            continue
        with tempfile.TemporaryDirectory() as td:
            src, dst = os.path.join(td, 'in.' + ext), os.path.join(td, 'out.jpeg')
            open(src, 'wb').write(parts[n])
            info = subprocess.run(['sips', '-g', 'hasAlpha', src], capture_output=True, text=True).stdout
            if ext == 'png' and 'hasAlpha: yes' in info:
                # Canal alpha présent : convertir seulement s'il est entièrement opaque (ImageMagick)
                try:
                    opaque = subprocess.run(['magick', 'identify', '-format', '%[opaque]', src], capture_output=True, text=True).stdout.strip()
                except FileNotFoundError:
                    opaque = ''
                if opaque != 'True':
                    continue
            subprocess.run(['sips', '-s', 'format', 'jpeg', '-s', 'formatOptions', '80', '-Z', '2000', src, '--out', dst], capture_output=True)
            if not os.path.exists(dst) or os.path.getsize(dst) > 0.7 * len(parts[n]):
                continue
            new = n.rsplit('.', 1)[0] + '-c.jpeg'
            parts[new] = open(dst, 'rb').read()
        old_b, new_b = posixpath.basename(n), posixpath.basename(new)
        for r in [r for r in parts if r.endswith('.rels')]:
            parts[r] = parts[r].replace(f'media/{old_b}"'.encode(), f'media/{new_b}"'.encode())
        print(f'  compressé : {old_b} {len(parts[n]) // 1024} Ko -> {new_b} {len(parts[new]) // 1024} Ko')
        del parts[n]

# 6. [Content_Types].xml : les noms de planches du template sont réutilisés, retirer toute
# déclaration de planche avant d'ajouter les nôtres, sinon PowerPoint voit un doublon.
ct = parts['[Content_Types].xml'].decode('utf-8')
ct = re.sub(r'<Override PartName="/([^"]*)"[^>]*/>',
            lambda m: m.group(0) if m.group(1) in parts and not m.group(1).startswith('ppt/slides/') else '', ct)
ct = ct.replace('</Types>', ''.join(f'<Override PartName="/{n}" ContentType="{CT_SLIDE}"/>' for _, _, n, _ in new_slides) + '</Types>')
for ext in sorted({n.rsplit('.', 1)[-1].lower() for n in parts if n.startswith('ppt/media/')}):
    if f'Extension="{ext}"' not in ct and ext in CT_IMG:
        ct = ct.replace('<Override ', f'<Default Extension="{ext}" ContentType="{CT_IMG[ext]}"/><Override ', 1)
names = re.findall(r'PartName="([^"]*)"', ct)
assert len(names) == len(set(names)), 'déclaration de type en double'
parts['[Content_Types].xml'] = ct.encode('utf-8')

# 7. docProps/app.xml : compteurs et titres de planches alignés
if 'docProps/app.xml' in parts:
    app = parts['docProps/app.xml'].decode('utf-8')
    for tag, v in (('Slides', len(new_slides)), ('Notes', 0), ('HiddenSlides', 0)):
        app = re.sub(rf'<{tag}>\d+</{tag}>', f'<{tag}>{v}</{tag}>', app)
    hp = re.search(r'<HeadingPairs><vt:vector size="(\d+)" baseType="variant">(.*?)</vt:vector></HeadingPairs>', app, re.S)
    tp = re.search(r'<TitlesOfParts><vt:vector size="(\d+)" baseType="lpstr">(.*?)</vt:vector></TitlesOfParts>', app, re.S)
    if hp and tp:
        pairs = re.findall(r'<vt:variant><vt:lpstr>([^<]*)</vt:lpstr></vt:variant><vt:variant><vt:i4>(\d+)</vt:i4></vt:variant>', hp.group(2))
        old = re.findall(r'<vt:lpstr>([^<]*)</vt:lpstr>', tp.group(2))
        if sum(int(c) for _, c in pairs) == len(old):
            new_pairs, new_titles, k = [], [], 0
            for name, c in pairs:
                chunk = old[k:k + int(c)]
                k += int(c)
                if 'diapositive' in name.lower() or 'slide' in name.lower():
                    chunk = [escape(t if isinstance(t, str) else ' '.join(map(str, t)))[:250] for _, _, _, t in new_slides]
                new_pairs.append((name, len(chunk)))
                new_titles += chunk
            hp_xml = ''.join(f'<vt:variant><vt:lpstr>{n}</vt:lpstr></vt:variant><vt:variant><vt:i4>{c}</vt:i4></vt:variant>' for n, c in new_pairs)
            tp_xml = ''.join(f'<vt:lpstr>{t}</vt:lpstr>' for t in new_titles)
            app = app.replace(hp.group(0), f'<HeadingPairs><vt:vector size="{2 * len(new_pairs)}" baseType="variant">{hp_xml}</vt:vector></HeadingPairs>')
            app = app.replace(tp.group(0), f'<TitlesOfParts><vt:vector size="{len(new_titles)}" baseType="lpstr">{tp_xml}</vt:vector></TitlesOfParts>')
    parts['docProps/app.xml'] = app.encode('utf-8')

with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as z:
    z.writestr('[Content_Types].xml', parts.pop('[Content_Types].xml'))
    for n, b in parts.items():
        z.writestr(n, b)
size = os.path.getsize(out_path)
print(f'écrit {out_path} | {len(new_slides)} planche(s) | mises en page : {len(used_layouts)} | médias générés : {media_count} | '
      f'{size // 1024} Ko | vue : {"trieuse" if "--sorter" in flags else "normale"}')
