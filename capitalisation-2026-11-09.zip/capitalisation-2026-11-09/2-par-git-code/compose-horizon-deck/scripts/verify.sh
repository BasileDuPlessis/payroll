#!/bin/zsh
# Ouvre une présentation dans PowerPoint, vérifie qu'elle s'ouvre sans réparation, exporte le
# rendu réel en PDF puis en PNG (une image par planche et une planche-contact).
# Usage : verify.sh FICHIER.pptx [DOSSIER_SORTIE]   (défaut : /tmp/horizon-deck-verify)
set -u
setopt NULL_GLOB
SRC="$1"
OUT="${2:-/tmp/horizon-deck-verify}"
HERE="${0:A:h}"
BOX="$HOME/Library/Containers/com.microsoft.Powerpoint/Data/tmp/horizon-deck"   # bac à sable de PowerPoint
mkdir -p "$OUT" "$BOX"
rm -f "$OUT"/page-*.png "$OUT"/planche-contact.png "$OUT"/rendu.pdf "$BOX"/rendu.pdf
cp "$SRC" "$OUT/verification.pptx"
pgrep -x "Microsoft PowerPoint" >/dev/null || { open -a "Microsoft PowerPoint"; sleep 8; }
RES=$(osascript <<OSA 2>&1
with timeout of 150 seconds
tell application "Microsoft PowerPoint"
  set avant to count of presentations
  open POSIX file "$OUT/verification.pptx"
  delay 6
  if (count of presentations) is avant then return "ECHEC"
  set k to 0
  repeat with i from 1 to count of presentations
    if name of presentation i is "verification.pptx" then set k to i
  end repeat
  if k is 0 then return "ECHEC"
  set r to "OK planches=" & (count of slides of presentation k)
  save presentation k in (POSIX file "$BOX/rendu.pdf") as save as PDF
  delay 3
  close presentation k saving no
  return r
end tell
end timeout
OSA
)
rm -f "$OUT/verification.pptx"
if [[ "$RES" != OK* ]]; then
  echo "ÉCHEC : PowerPoint n'a pas ouvert le fichier ($RES)."
  echo "Une demande de réparation est sans doute affichée : cliquer sur Annuler, puis corriger le fichier."
  exit 1
fi
echo "$RES"
cp "$BOX/rendu.pdf" "$OUT/rendu.pdf" && rm -rf "$BOX"
swift "$HERE/pdf2png.swift" "$OUT/rendu.pdf" "$OUT/page" 1800 >/dev/null
PAGES=("$OUT"/page-*.png(n))
if command -v magick >/dev/null && (( ${#PAGES} > 1 )); then
  COLS=$(( ${#PAGES} >= 4 ? 2 : ${#PAGES} ))
  magick montage "${PAGES[@]}" -tile "${COLS}x" -geometry 1100x+24+24 -background '#E7E6E6' "$OUT/planche-contact.png" 2>/dev/null
fi
print -l "${PAGES[@]}" "$OUT"/planche-contact.png
