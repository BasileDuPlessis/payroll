# Tableau de bord de la capitalisation agentique

Document de travail du 05/11/2026, non partagé. Destinataire visé : management du programme Horizon.

Planche : [`22-tableau-de-bord-capitalisation.pptx`](22-tableau-de-bord-capitalisation.pptx), une planche sur le template [`../templates/Template Horizon 2026 05-01-26.pptx`](<../templates/Template Horizon 2026 05-01-26.pptx>), mise en page « Titre et contenu ». Les deux fichiers ne gardent que cette mise en page et le masque, ce qui les fait passer de 7 Mo à moins de 100 Ko. Les autres mises en page, avec leurs photos, restent dans le template complet. Les planches gardent l'étiquette de sensibilité EDF « C1 Interne » héritée du template, comme les présentations faites à la main sur ce template. Les fichiers ont été réenregistrés par PowerPoint.

Variantes allégées : [`22-tableau-de-bord-capitalisation-variantes.pptx`](22-tableau-de-bord-capitalisation-variantes.pptx), quatre planches qui s'ouvrent en trieuse de diapositives, avec un aperçu côte à côte dans [`22-tableau-de-bord-capitalisation-variantes.png`](22-tableau-de-bord-capitalisation-variantes.png). Voir la section « Progression vers la cible ».

Source : inventaire du dépôt de l'équipe au 05/11/2026, ≈ 113 assets : 59 skills, 10 customisations BMAD, ≈ 14 hooks, 10 serveurs MCP, 20 patterns, pratiques et conventions. Les écarts de comptage sont listés plus bas.

La planche répond à cinq questions : où en est la capitalisation, couvre-t-elle tous les domaines, que reste-t-il à couvrir, pourquoi le faire, pourquoi ce n'est pas encore fait.

## Mise à jour du 09/11/2026

- **Variante retenue :** la A, grille des points avec la bande des 4 critères.
- **Digital retiré du suivi.** La skill `edfdco-maquette-vers-lwc`, qui y était rattachée, passe en Design / UX.
- **Texte de droite remplacé par un cadre « Plan d'action »,** rempli chaque semaine par l'équipe. La progression vers la cible reste affichée au-dessus.
- **Nouvelle cible :** 13 domaines, soit 104 points. Au 09/11 : 76 points, 73 % de la cible, 4 couverts, 7 partiels, 1 amorcé, 1 non couvert. À périmètre constant, rien n'a bougé depuis le 05/11 ; la hausse de 70 à 73 % vient du seul retrait du Digital.
- **Nouvelle source de vérité :** [`22-capitalisation-affectation-assets.md`](22-capitalisation-affectation-assets.md). Elle contient les domaines, la grille justifiée case par case, l'affectation des assets, le plan d'action et l'historique. Elle remplace l'annexe et les tableaux d'état de cette fiche, conservés comme photographie du 05/11.
- **Script de la planche,** versionné à côté de la table : [`22-tableau-de-bord-capitalisation-deck.js`](22-tableau-de-bord-capitalisation-deck.js), à lancer depuis la racine du dépôt avec la skill `compose-horizon-deck`.
- **Procédure hebdomadaire et ajout de nouveaux SI après l'Éditique :** [`22-prompt-suivi-hebdo-capitalisation.md`](22-prompt-suivi-hebdo-capitalisation.md).
- **Planche courante :** `22-tableau-de-bord-capitalisation.pptx` porte désormais la version hebdomadaire. La version dense du 05/11 reste dans l'historique git ; les variantes restent dans `22-tableau-de-bord-capitalisation-variantes.pptx` et dans `livrables/`.

## Message

Titre : *Capitalisation agentique : 4 domaines sur 14 couverts, 7 à compléter, 3 à ouvrir.*

Pitch : *Ce qu'une équipe apprend une fois, tous les agents l'appliquent ensuite à chaque feature : la capitalisation transforme l'expertise rare des socles en vitesse de delivery reproductible.*

Amélioration continue : maintenir les assets fait partie du travail de l'équipe. Chaque incident, revue ou correction enrichit un asset existant. Exemples : les 17 règles « Ce qui vaut preuve », chacune adossée à un incident mesuré, et les 4 variantes DA/DCA fusionnées dans le pipeline unique `edfdco-da`.

## Domaines suivis

Liste stable, validée par Basile le 05/11/2026. Le domaine « Dépôt BMAD multi-équipes » a été ajouté le même jour. Un domaine ne change pas d'une édition à l'autre, et tout ajout se date ici.

| Famille | Domaine | Ce qui y entre |
|---|---|---|
| Métier et conception | Instruction métier | Brief, distillation des entrants, PRD, epics et stories, MOE, cohérence PRD / architecture / epics |
| | Design / UX | Référentiel UX, maquettes, accessibilité, règles UX des parcours |
| | Digital | Parcours digitaux et Espace Client, reprise des parcours UX produits par l'équipe digitale |
| Architecture et SI | Architecture | DA/DCA, patterns ArchiMate, flux, contrats d'interface, événements × SI, référentiel EA |
| | SI Canopée | Salesforce, LWC, Copado, CRT |
| | SI Plaasma | MuleSoft, Jenkins, Anypoint, OAuth2 |
| | SI Camunda | BPMN, FEEL, Operate, workers et connecteurs |
| | SI Facthori | SAP IS-U, ABAP, OData, RFC |
| | SI Éditique | Outils de l'Éditique, transactionnel et batch |
| Transverse | Tests et qualité | Tests E2E, de contrat et de non-régression, revue de code, règles de preuve |
| | Sécurité et conformité | OWASP, secrets, RGPD, dossiers de conformité, contrôles de sécurité |
| | Exploitation et MCO | Déploiement, supervision SPOT, logs, instruction d'anomalie, procédure de MCO |
| | Dépôt BMAD multi-équipes | Arborescence multi-projets, partage des assets entre équipes, synchronisation, intégrité du harnais |
| | Méthode et pilotage | Cockpit, habilitations, gouvernance SAFe, processus de développement assisté, publication |

## Grille de lecture

Chaque domaine est noté sur quatre dimensions, qui correspondent aux quatre types d'assets du harnais.

| Dimension | Question | Assets qui comptent |
|---|---|---|
| Connaître | Que sait l'agent du domaine ? | Pratiques, conventions, patterns, rétro-documentation, agents conseillers |
| Produire | Que sait-il faire ? | Skills, customisations BMAD, scripts de production |
| Accéder | Que peut-il voir et atteindre ? | Serveurs MCP, synchronisations, accès outillés |
| Contrôler | Qu'est-ce qui l'empêche de se tromper ? | Hooks, tests, revues, contrôles avant déploiement |

Notation : ● outillé, 2 points ; ○ partiel, 1 point ; – absent, 0 point. État : Couvert 8/8, Partiel de 4 à 7, Amorcé de 1 à 3, Non couvert 0.

Règle d'affectation : chaque asset a un domaine principal, qui sert au comptage, et peut contribuer à d'autres domaines. Seul l'inventaire du 05/11 fait foi. Un asset qui existe hors inventaire n'est pas compté et se signale en point à confirmer. Le contrôle de cohérence vérifie qu'une note positive repose sur au moins un asset et qu'une note nulle n'en cache aucun : aucune incohérence au 05/11.

## État au 05/11/2026

| Domaine | Connaître | Produire | Accéder | Contrôler | Points | État | Ce qui manque |
|---|---|---|---|---|---|---|---|
| Instruction métier | ● | ● | ● | ● | 8 | Couvert | |
| Design / UX | – | ○ | – | ● | 3 | Amorcé | Référentiel UX, accès outillé aux maquettes. Seuls les garde-fous existent |
| Digital | – | ○ | – | ○ | 2 | Amorcé | Reprise automatique des parcours UX de l'équipe digitale, à instruire |
| Architecture | ● | ● | ● | ● | 8 | Couvert | |
| SI Canopée | ○ | ● | ● | ● | 7 | Partiel | Conventions propres à Canopée : l'inventaire n'a que le miroir du code et des skills Salesforce génériques héritées d'ae-skills |
| SI Plaasma | ● | ○ | ● | ● | 7 | Partiel | Skills de développement MuleSoft : préfixe `mulesoft-*` vide, plugin plaasma hors inventaire |
| SI Camunda | – | ○ | ● | ● | 5 | Partiel | Conventions Camunda, développement des workers et connecteurs |
| SI Facthori | ● | ● | ● | ● | 8 | Couvert | |
| SI Éditique | – | – | – | – | 0 | Non couvert | Tout, premier contact le 03/11 |
| Tests et qualité | ● | ○ | ○ | ● | 6 | Partiel | Tests de contrat inter-SI et de non-régression transverse, non identifiés dans l'inventaire |
| Sécurité et conformité | ● | ○ | ○ | – | 4 | Partiel | Contrôle de sécurité automatisé |
| Exploitation et MCO | ○ | ● | ● | ● | 7 | Partiel | Procédure de MCO |
| Dépôt BMAD multi-équipes | ○ | ○ | ● | ○ | 5 | Partiel | Arborescence et règles de partage documentées, contrôle de la duplication du patrimoine partagé, skill de création de projet |
| Méthode et pilotage | ● | ● | ● | ● | 8 | Couvert | |

## Progression vers la cible

Cible : les 14 domaines outillés sur les 4 critères, soit 112 points. Au 05/11/2026, 78 points sont acquis, soit 70 % de la cible. Ce pourcentage découle de la notation retenue, où ● vaut 2 points et ○ en vaut 1 : un critère partiel compte donc pour moitié. Cette convention est à valider.

| Critère | Points | Progression | Domaines outillés | À outiller (–) | À compléter (○) |
|---|---|---|---|---|---|
| Connaître | 17 / 28 | 61 % | 7 sur 14 | Design / UX, Digital, Camunda, Éditique | Canopée, Exploitation, Dépôt BMAD |
| Produire | 19 / 28 | 68 % | 6 sur 14 | Éditique | Design / UX, Digital, Plaasma, Camunda, Tests, Sécurité, Dépôt BMAD |
| Accéder | 20 / 28 | 71 % | 9 sur 14 | Design / UX, Digital, Éditique | Tests, Sécurité |
| Contrôler | 22 / 28 | 79 % | 10 sur 14 | Éditique, Sécurité | Digital, Dépôt BMAD |

Lecture : les garde-fous sont plus avancés que la connaissance documentée.

Le 05/11 est le premier point de mesure. À partir de l'édition suivante, l'écart avec l'édition précédente pourra s'afficher pour chaque domaine et pour l'ensemble.

Quatre variantes allégées de la planche, proposées le 05/11 et à arbitrer. Les variantes A, B et C portent sous le pitch une bande « Les 4 critères », qui reprend les définitions des cartes de la D (question, puis types d'assets) avec une case de lecture des marques.

| Variante | Principe | Ce qu'elle retire de la planche complète |
|---|---|---|
| A · grille allégée | Grille des points, deux indicateurs en tête, priorités, raisons et freins en une ligne chacun | Assets phares, répartition par type, listes détaillées |
| B · barres de progression | Chaque domaine est une barre de 4 segments à remplir ; à droite, le pourcentage de la cible, les domaines couverts, la progression par critère et 3 priorités | Assets phares, répartition par type, raisons et freins |
| C · mur de domaines | Une tuile par domaine, à la couleur de son état, avec sa barre de critères et son score ; à gauche, le pourcentage de la cible et 3 priorités | Détail par critère en colonnes, raisons et freins |
| D · progression par critère | Une carte par critère avec son pourcentage, les domaines à outiller et à compléter | Vue domaine par domaine |

## Ce qui reste à couvrir, pourquoi le faire, pourquoi ce n'est pas encore fait

L'ordre de la liste suit l'écart à combler, du domaine sans asset au domaine presque couvert. C'est une proposition, pas un arbitrage.

Reste à couvrir :

1. Éditique : aucun asset, premier contact le 03/11.
2. Digital : reprise automatique des parcours UX que l'équipe digitale conçoit avec Claude, à instruire.
3. Sécurité : aucun contrôle automatisé.
4. Tests de contrat inter-SI et de non-régression transverse.
5. Design / UX : référentiel UX, accès aux maquettes.
6. Dépôt multi-équipes : arborescence et règles de partage.
7. Socles : conventions Camunda et Canopée ; skills de développement Plaasma, à confirmer.
8. Exploitation : procédure de MCO.

Pourquoi le faire :

- Sans asset, un domaine dépend de quelques experts, dont la disponibilité limite le passage à l'échelle. Source : restitution du 24/07, planche 21, reprise dans [`06`](06-suivi-et-questions-ouvertes.md).
- Un asset sert toutes les équipes du dépôt. Source : décision du 11/09 avec AMIA, qui rend le patrimoine capitalisable au niveau de l'équipe, du programme et de toute équipe BMAD, voir [`05`](05-decisions.md).
- Les garde-fous rendent le travail de l'agent vérifiable par les socles.

Pourquoi ce n'est pas encore fait :

- Les assets naissent des features : la chaîne du pilote est la mieux couverte. Constat tiré de la grille.
- Digital : phase 3 de la feuille de route Vente, d'après le PCV du 06/10. Éditique : la refonte ROCK est en pause et l'outil cible n'est pas arrêté, voir [`04-referentiel.md`](04-referentiel.md).
- Sécurité : une analyse de failles par LLM public classe l'activité en C3, ce qui rend cet usage non autorisé. La cible est un modèle open-weight en environnement souverain.
- Plaasma : MuleSoft a publié le 17/09 les skills et scripts utilisés par Vibes ; leur intégration dans BMAD est à l'étude.
- Dépôt : l'arborescence et les règles de partage sont à documenter depuis la restructuration du 14/09. Une réflexion a été engagée le 02/11.

## Points à confirmer

| Point | Constat | Effet sur la planche |
|---|---|---|
| Nombre de skills | L'en-tête de l'inventaire annonce 46 skills ; la liste en énumère 59, soit 47 `edfdco-*`, `hrz-*` et `logs-*`, plus 12 `sf-*` | La planche retient 59, seul chiffre cohérent avec le total |
| Nombre de serveurs MCP | L'en-tête annonce 11 ; la liste en énumère 10, Anypoint étant porté par le plugin plaasma hors périmètre | La planche retient 10 |
| Total | La somme des en-têtes donne 101 ; le total annoncé de ≈ 113 correspond à 59 + 10 + 14 + 10 + 20 | La planche retient ≈ 113 |
| Comparaison au 29/09 | Le PCV du 29/09 affichait 90 assets. Son script ne compte pas les fichiers `.toml`, donc pas les 10 customisations BMAD : le chiffre comparable au 05/11 serait d'environ 103 | Mention « comptage à harmoniser » |
| Harnais de test LWC | Affiché au PCV du 29/09 (Jest, composants Canopée), absent de l'inventaire du 05/11 | Non compté |
| Variantes DA/DCA | Les 4 variantes historiques, remplacées par `edfdco-da`, sont comptées dans les 59 skills | À décider : les garder dans le total ou les retirer |
| Plaasma | Le plugin plaasma, hors inventaire, peut porter des skills de développement | Produire noté ○, à confirmer |
| Skill de création de projet | Évoquée au lancement d'I-Know-Kung-Fu le 19/10, absente de l'inventaire | Dépôt BMAD multi-équipes, Produire noté ○ |
| Digital | Besoin signalé le 05/11 : l'équipe digitale conçoit des parcours UX avec Claude et attend leur reprise par l'équipe. Format d'échange, outil et responsabilité de la reprise restent à instruire. `edfdco-maquette-vers-lwc`, qui implémente une maquette HTML ou Figma en LWC Experience Cloud, en est le point de départ | Hypothèse, à instruire |
| Canopée | Aucune convention propre à Canopée dans l'inventaire | Connaître noté ○, à confirmer |
| Hooks | L'inventaire annonce ≈ 14 cibles. L'annexe les détaille en 9 groupes de hooks et 14 scripts d'outillage, soit 122 lignes au lieu de 113 | Sans effet sur la planche |

## Mise à jour

À chaque nouvel inventaire :
1. Affecter chaque nouvel asset à un domaine principal et à une dimension, puis noter ses contributions aux autres domaines.
2. Revoir les notes ● et ○, puis recalculer les états : la règle reste celle de la grille de lecture.
3. Régénérer la planche à partir de ce fichier.

La liste des domaines ne change pas, sauf ajout daté.

## Annexe : affectation des assets par domaine

« Contribue » signale un asset compté dans un autre domaine principal.

**Instruction métier** · Couvert, 8/8 · 13 assets en domaine principal

- Connaître ● : edfdco-moe-distill, bmad-agent-pm, Convention entrants, Convention relecture et suivi
- Produire ● : edfdco-distill, edfdco-brief, edfdco-bpmn-to-prd, hrz-bmad-to-jira, bmad-product-brief, bmad-prd, bmad-create-epics-and-stories
- Accéder ● : MCP Gateway EDF (contribue)
- Contrôler ● : edfdco-docreview, edfdco-project-checkpoint

**Design / UX** · Amorcé, 3/8 · 2 assets en domaine principal

- Connaître – : aucun asset dans l'inventaire
- Produire ○ : edfdco-maquette-vers-lwc (contribue)
- Accéder – : aucun asset dans l'inventaire
- Contrôler ● : edfdco-pdg-lwc-guard, edfdco-agent-wcag-auditor

**Digital** · Amorcé, 2/8 · 1 asset en domaine principal

- Connaître – : aucun asset dans l'inventaire
- Produire ○ : edfdco-maquette-vers-lwc
- Accéder – : aucun asset dans l'inventaire
- Contrôler ○ : edfdco-agent-wcag-auditor (contribue), edfdco-crt-dev (contribue)

**Architecture** · Couvert, 8/8 · 30 assets en domaine principal

- Connaître ● : edfdco-agent-data-architect, bmad-agent-architect, Référentiel de patterns d'intégration, Arbre de décision des patterns, Pratique Kafka vs IBM MQ, Convention avancement conception des flux, Convention diagrammes, Convention matrice événements × SI, Convention référentiel de connaissances EA
- Produire ● : edfdco-da, edfdco-da-dca, edfdco-da-dca-officiel, edfdco-da-plaasma, edfdco-da-arom, edfdco-pattern-lifecycle, edfdco-archi-arbitrage, edfdco-archi-exporter, edfdco-archimate-flow-analyzer, edfdco-archimate-pattern-template-gen, edfdco-archimate-pattern-wizard, edfdco-archimate-product-gen, edfdco-cartographie-flux, edfdco-dossier-flux, edfdco-evenements-si, edfdco-diagram-gen, edfdco-tech-arch-designer, hrz-create-contrat-interface, edfdco-archi-to-bpmn (contribue), bmad-create-architecture
- Accéder ● : edfdco-leonard-sync-agent, MCP Gateway EDF (contribue)
- Contrôler ● : edfdco-project-checkpoint (contribue), edfdco-agent-vitruve

**SI Canopée** · Partiel, 7/8 · 18 assets en domaine principal

- Connaître ○ : Script init/fraîcheur miroir sf-main
- Produire ● : 12 skills Salesforce sf-platform-*, sf-experience-*, sf-integration-*, edfdco-maquette-vers-lwc (contribue), Script sync des skills ae-skills
- Accéder ● : MCP Copado Agentia
- Contrôler ● : edfdco-pdg-lwc-guard (contribue), edfdco-crt-dev (contribue), edfdco-supervise-e2e (contribue), Hook Salesforce / Apex, Hook Agentia / Copado, Script hygiène données de test Apex

**SI Plaasma** · Partiel, 7/8 · 4 assets en domaine principal

- Connaître ● : Pratique OAuth2 Plaasma
- Produire ○ : edfdco-da-plaasma (contribue), hrz-create-contrat-interface (contribue)
- Accéder ● : MCP Jenkins, MCP CloudWatch (contribue)
- Contrôler ● : edfdco-supervise-e2e (contribue), Hook Plaasma, Hook Jenkins

**SI Camunda** · Partiel, 5/8 · 3 assets en domaine principal

- Connaître – : aucun asset dans l'inventaire
- Produire ○ : edfdco-archi-to-bpmn
- Accéder ● : MCP Camunda
- Contrôler ● : edfdco-supervise-e2e (contribue), Hook Camunda

**SI Facthori** · Couvert, 8/8 · 7 assets en domaine principal

- Connaître ● : edfdco-facthori-retrodocumentation, Pratique analyse de l'existant SAP
- Produire ● : edfdco-facthori-odata-v2, edfdco-facthori-rfc-dev
- Accéder ● : MCP SAP RFC
- Contrôler ● : Hook SAP, Script classification RFC SAP

**SI Éditique** · Non couvert, 0/8 · 0 asset en domaine principal

- Connaître – : aucun asset dans l'inventaire
- Produire – : aucun asset dans l'inventaire
- Accéder – : aucun asset dans l'inventaire
- Contrôler – : aucun asset dans l'inventaire

**Tests et qualité** · Partiel, 6/8 · 5 assets en domaine principal

- Connaître ● : Pratique « Ce qui vaut preuve », Pratique processus de développement assisté (contribue)
- Produire ○ : edfdco-crt-dev
- Accéder ○ : MCP Copado Agentia (contribue), Script hygiène données de test Apex (contribue)
- Contrôler ● : edfdco-supervise-e2e, bmad-code-review, Hook Agentia / Copado (contribue), Hook sonde jetable

**Sécurité et conformité** · Partiel, 4/8 · 3 assets en domaine principal

- Connaître ● : edfdco-agent-data-governance, Pratique OAuth2 Plaasma (contribue), Pratique sécurité applicative OWASP
- Produire ○ : edfdco-da (contribue), edfdco-da-dca (contribue), edfdco-da-dca-officiel (contribue)
- Accéder ○ : edfdco-openbao
- Contrôler – : aucun asset dans l'inventaire

**Exploitation et MCO** · Partiel, 7/8 · 8 assets en domaine principal

- Connaître ○ : Pratique logs minimaux SPOT
- Produire ● : edfdco-anomalie, logs-mini-skill
- Accéder ● : MCP Copado Agentia (contribue), MCP Jenkins (contribue), MCP CloudWatch, MCP Config Cohorte, MCP Elasticsearch, MCP Clark, MCP SSH SPOT
- Contrôler ● : Hook Camunda (contribue), Hook Salesforce / Apex (contribue), Hook Jenkins (contribue)

**Dépôt BMAD multi-équipes** · Partiel, 5/8 · 6 assets en domaine principal

- Connaître ○ : edfdco-guide-parcours (contribue), Convention OKF frontmatter
- Produire ○ : bmad-create-story, Script détection projet BMAD actif
- Accéder ● : edfdco-habilitations (contribue), Script sync git, Script sync des skills ae-skills (contribue)
- Contrôler ○ : Convention hooks, Hook git-hooks / claude-hooks

**Méthode et pilotage** · Couvert, 8/8 · 22 assets en domaine principal

- Connaître ● : edfdco-guide-parcours, bmad-agent-dev, Pratique gouvernance SAFe, Pratique processus de développement assisté, Convention publication Confluence, Convention visuels de diapositive
- Produire ● : edfdco-cockpit, edfdco-fill-pptx, edfdco-agent-session-handover, edfdco-habilitations, bmad-dev-story, Script check présences, Script status line connexions, Script maj date dashboard, Script chaîne de publication Confluence, Script convertisseurs Markdown/Mermaid
- Accéder ● : edfdco-mcp-jira-setup, MCP Gateway EDF, Script refresh token Gardian
- Contrôler ● : Hook Confluence, Script audit MCP, Script préflight connexions expirantes

