---
name: compose-horizon-deck
description: Produire une présentation PowerPoint au format Horizon (un pptx, un deck, une planche, des slides au format ou à la charte Horizon, sur le template Horizon) — couverture, intercalaires, planches de texte, de colonnes ou libres comme un tableau de bord, citation, fin — générée, greffée sur le template EDF Horizon 2026 et vérifiée dans PowerPoint.
---

# Skill : compose-horizon-deck (présentations au format Horizon)

Cette compétence produit des fichiers `.pptx` qui utilisent vraiment le template Horizon : son masque, ses logos, ses mises en page et ses styles de titre et de texte. Elle ne se contente pas d'imiter la charte. Le contenu libre, comme un tableau de bord, des jauges, des pastilles d'état ou des cartes, se dessine avec les couleurs et la police du thème.

Recette établie le 05/11/2026, en produisant le tableau de bord de la capitalisation : `synthese/22-tableau-de-bord-capitalisation*.pptx`. Les pièges listés plus bas ont tous été rencontrés ce jour-là.

## Prérequis

- macOS, Node, Python 3 et Swift (outils de développement Apple), plus Microsoft PowerPoint pour la vérification. ImageMagick est facultatif : il sert à la planche-contact et à la compression des PNG munis d'un canal alpha.
- Une seule fois : `scripts/setup.sh`. Il installe `pptxgenjs` dans `~/.cache/horizon-deck`, hors du dépôt.
- Le template se trouve dans `templates/Template Horizon 2026 05-01-26.pptx`. Il ne se modifie pas.
- Le catalogue des mises en page et de leurs espaces réservés est dans [`references/layouts.md`](references/layouts.md).

## Recette

1. **Cadrer.** Fixer le destinataire, le nombre de planches et le message de chacune. Chaque titre énonce un message, pas un thème : « 70 % de la cible atteinte », et non « Avancement ».
2. **Écrire le script de la présentation** dans un dossier de travail hors du dépôt, par exemple `/tmp/<objet>/deck.js`, en partant de [`scripts/example.js`](scripts/example.js). Charger la bibliothèque par son chemin absolu : `require('<racine du dépôt>/.claude/skills/compose-horizon-deck/scripts/horizon.js')`.
3. **Construire.** `node /tmp/<objet>/deck.js /tmp/<objet>/deck` écrit `deck.pptx` (les formes libres) et `deck.json` (les mises en page et le texte des espaces réservés).
4. **Greffer sur le template.**
   ```
   python3 -I .claude/skills/compose-horizon-deck/scripts/graft.py \
     "templates/Template Horizon 2026 05-01-26.pptx" /tmp/<objet>/deck.pptx /tmp/<objet>/deck.json SORTIE.pptx --compress
   ```
   Options :
   - `--compress` : recompresse en JPEG les photos de plus de 400 Ko des mises en page conservées ;
   - `--sorter` : ouvre le fichier en trieuse de diapositives, pour comparer des variantes ;
   - `--keep-layouts` : garde les 26 mises en page du template, par exemple si le destinataire doit ajouter des planches. Le fichier pèse alors 7 Mo.
5. **Vérifier dans PowerPoint.** `.claude/skills/compose-horizon-deck/scripts/verify.sh SORTIE.pptx /tmp/<objet>/verif` ouvre le fichier, confirme qu'il s'ouvre sans demande de réparation, puis exporte une image par planche et une planche-contact.
   Lire ces images avec Read et contrôler qu'aucun texte ne déborde, qu'aucun bloc n'en chevauche un autre, que rien ne touche la zone des logos et que chaque planche ne porte qu'un message.
   L'aperçu macOS (`qlmanage`) ne suffit pas : Work Sans n'y est pas installée, il la remplace par une police plus étroite et sous-estime donc la largeur des textes.
6. **Corriger puis reconstruire** jusqu'à obtenir un rendu propre.
7. **Déposer.**
   - Une version de travail va dans `synthese/NN-objet.pptx`, avec sa fiche source en Markdown.
   - Le jour du partage avec EDF, déposer la copie figée sous `livrables/YYYY-MM-DD-objet.pptx` et ajouter sa ligne à l'index. Une correction ultérieure se dépose sous une nouvelle date.
   - Ne commiter que sur demande.

## Bibliothèque `horizon.js`

| Méthode | Planche |
|---|---|
| `d.cover({ title, subtitle, date })` | Couverture avec photo |
| `d.section({ number, title, subtitle })` | Intercalaire numéroté |
| `d.content({ title, body })` | Texte : `body` est une liste de paragraphes, chaînes ou `{ text, level }`, avec `**gras**` |
| `d.columns({ title, cols: [{ head, body }] })` | 2, 3 ou 4 colonnes |
| `d.free({ title, compact }, (k) => { … })` | Planche libre, titre compact par défaut (20 pt sur une ligne) |
| `d.quote({ text, author })` | Citation pleine page |
| `d.end()` | Planche « Merci » |
| `d.slide(nomDeMiseEnPage, ph, { compactTitle })` | Toute autre mise en page du catalogue |
| `d.save('/tmp/<objet>/deck')` | Écrit `deck.pptx` et `deck.json` |

Le kit `k`, reçu par `free()` et renvoyé par chaque méthode, offre ces composants :
- `pitch(texte)` : bandeau marine à liseré orange ;
- `note(libellé, texte)` : bandeau gris en bas de planche ;
- `head(texte, x, y, w)` : intertitre souligné d'un filet orange ;
- `stat(x, y, w, h, libellé, valeur, précision)` : tuile chiffre ;
- `meter(x, y, w, h, fraction)` : jauge ;
- `card(x, y, w, h, titre, texte)` : carte à filet bleu ;
- `pill(état, x, y, w, h)` : pastille d'état portant son libellé ;
- `dot(v, cx, cy)` : marque 2, 1 ou 0 ;
- `segbar(x, y, w, h, valeurs, couleur)` : barre segmentée ;
- `numbered(éléments, x, y, w)` et `bullets(éléments, x, y, w, h)` : listes ;
- `tag(texte)` : mention discrète entre les logos ;
- `T` et `TB` : texte en Work Sans et Work Sans SemiBold ;
- `R` et `RR` : rectangle et rectangle arrondi ;
- `k.s` : planche pptxgenjs brute, par exemple pour `addImage` ou `addTable`.

Les constantes `C` (couleurs), `STATUS` (états) et `SAFE` (zones sûres) sont exportées.

## Règles de rédaction

- **Un message par planche, porté par le titre.**
- **Densité :** le 05/11, la première version du tableau de bord a été jugée trop dense. Viser au plus un bandeau et trois blocs par planche, et pas de texte sous 7 pt. Ce qui ne tient pas va dans les notes, une annexe ou une planche de plus.
- **Statut de l'information :** distinguer explicitement ce qui est validé, ce qui est une hypothèse, ce qui reste à confirmer et ce qui est simulé.
- **Conventions de la mission :** écrire `Plaasma`. Aucune donnée client réelle. Pas de tournure « l'idée n'est pas de…, mais de… ».
- **Versions de travail :** une version de travail ou une variante porte `tag('Version de travail')`, à retirer avant diffusion.

## Règles de mise en page

- **Zones sûres, en pouces sur 13,33 × 7,5 :**
  - de x = 0,4 à x = 12,93 ;
  - à partir de y = 0,8 sous un titre compact, ou de y = 1,6 sous un titre standard ;
  - jusqu'à y = 6,46 au plus.
  
  Sous 6,46, le masque place le logo EDF à gauche, le logo Horizon et le numéro de page à droite. Seule `tag()` se loge entre les deux logos.
- **Couleurs du thème :**
  - marine `001A70`, bleu `1057C8`, bleu clair des titres `1089FF`, orange `FE5716`, ambre `FFB210` ;
  - jauges : `1057C8` sur `DCE6F7` ;
  - fonds : `F2F4F8` ;
  - filets : `D9DCE3`.
- **États :** une couleur d'état s'accompagne toujours de son libellé, la couleur ne porte jamais seule l'information.
- **Police :** Work Sans pour le texte, Work Sans SemiBold pour l'emphase, Work Sans Light pour les titres, ces derniers repris des styles du template.

## Pièges connus, corrigés par `graft.py`

| Piège | Symptôme | Correction |
|---|---|---|
| Planches d'exemple du template | 48 planches parasites | Retirées, avec leurs notes et commentaires |
| Déclaration de type en double, la planche n° 1 du template portant le même nom de partie | « PowerPoint a détecté un problème dans le contenu », réparation proposée | Toute déclaration de planche purgée avant d'ajouter les nouvelles ; un contrôle bloque tout doublon |
| `lastView="sldMasterView"` dans `ppt/viewProps.xml` | Le fichier s'ouvre en mode masque | Vue normale, ou trieuse avec `--sorter` |
| Photos des mises en page de couverture, d'intercalaire et de fin | Environ 7 Mo, envoi par mail pénible | Seules les mises en page utilisées sont gardées ; `--compress` recompresse les photos opaques |
| Miniature d'aperçu héritée | Le Finder montre la couverture du template | Miniature retirée |

L'étiquette de sensibilité EDF « C1 Interne », portée par `docProps/custom.xml` et `docMetadata/LabelInfo.xml`, est conservée : c'est normal pour un contenu Horizon.

## Envoi

Si l'envoi échoue, lire la section « Error Details » du message de non-remise avant de chercher la cause dans le fichier. Le 05/11, le code `550 5.1.0 Address rejected` venait d'une adresse de destinataire erronée, pas de la présentation.

## Non-régression

Après toute modification des scripts, reconstruire `example.js`, greffer avec `--compress` et passer `verify.sh`. Le résultat attendu : 7 planches qui s'ouvrent sans réparation, environ 2 Mo, et une planche-contact propre.
