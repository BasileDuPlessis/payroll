# Capitalisation agentique : affectation des assets et grille de suivi

Source de vérité de la planche hebdomadaire `22-tableau-de-bord-capitalisation.pptx`. Tenue à jour par Claude chaque semaine, revue par l'équipe. Toute note de la grille est validée par un humain avant publication.

Édition en cours : 09/11/2026

Inventaire de référence : export du dépôt de l'équipe au 05/11/2026, ≈ 113 assets. Règles et contexte : [`22-tableau-de-bord-capitalisation.md`](22-tableau-de-bord-capitalisation.md). Procédure hebdomadaire : [`22-prompt-suivi-hebdo-capitalisation.md`](22-prompt-suivi-hebdo-capitalisation.md).

## Règles

| Critère | Ce qu'il mesure | Assets qui comptent |
|---|---|---|
| Connaître | Ce que l'agent sait du domaine | Pratiques, conventions, patterns, rétro-documentation, agents conseillers |
| Produire | Ce que l'agent sait faire | Skills, customisations BMAD, scripts de production |
| Accéder | Ce que l'agent peut voir et atteindre | Serveurs MCP, synchronisations, accès outillés |
| Contrôler | Ce qui l'empêche de se tromper | Hooks, tests, revues, contrôles avant déploiement |

- **Note d'une case :** ● outillé = 2 points, ○ partiel = 1 point, – absent = 0 point.
- **Sens des notes :**
  - ● : un asset dédié couvre le besoin principal du critère pour ce domaine ;
  - ○ : un asset existe mais un maillon important manque, et la colonne « Pour passer à ● » le nomme ;
  - – : aucun asset de l'inventaire.
- **État d'un domaine,** sur 8 points : Couvert = 8 ; Partiel = de 4 à 7 ; Amorcé = de 1 à 3 ; Non couvert = 0.
- **Cible :** tous les domaines suivis, outillés sur les 4 critères, soit 8 points par domaine. Progression vers la cible = points ÷ cible.
- **Cohérence :**
  - une note supérieure à 0 exige au moins un asset de la table Assets dans la case, en domaine principal ou en contribution ;
  - une note de 0 interdit tout asset dans la case.
- **Ajouter un SI**, après SI Éditique :
  - une ligne dans Domaines, famille « Architecture et SI », placée juste après le dernier SI, avec un code de deux lettres ;
  - quatre lignes dans Grille, notées – au départ ;
  - une ligne d'historique qui signale l'élargissement de la cible (+8 points).

  Le pourcentage baisse mécaniquement à l'ajout : la planche compare toujours les éditions à périmètre constant.
- **Retirer un domaine :** passer son statut à « Retiré le … » dans Domaines et supprimer ses lignes de Grille. Ses assets sont réaffectés ou leur contribution est retirée.

## Domaines

| Ordre | Code | Famille | Domaine | Suivi depuis | Statut |
|---|---|---|---|---|---|
| 1 | IM | Métier et conception | Instruction métier | 05/11/2026 | Suivi |
| 2 | UX | Métier et conception | Design / UX | 05/11/2026 | Suivi |
| 3 | AR | Architecture et SI | Architecture | 05/11/2026 | Suivi |
| 4 | CA | Architecture et SI | SI Canopée | 05/11/2026 | Suivi |
| 5 | PL | Architecture et SI | SI Plaasma | 05/11/2026 | Suivi |
| 6 | CM | Architecture et SI | SI Camunda | 05/11/2026 | Suivi |
| 7 | FA | Architecture et SI | SI Facthori | 05/11/2026 | Suivi |
| 8 | ED | Architecture et SI | SI Éditique | 05/11/2026 | Suivi |
| 9 | TQ | Transverse | Tests et qualité | 05/11/2026 | Suivi |
| 10 | SE | Transverse | Sécurité et conformité | 05/11/2026 | Suivi |
| 11 | EX | Transverse | Exploitation et MCO | 05/11/2026 | Suivi |
| 12 | DB | Transverse | Dépôt BMAD multi-équipes | 05/11/2026 | Suivi |
| 13 | MP | Transverse | Méthode et pilotage | 05/11/2026 | Suivi |
| – | DG | Métier et conception | Digital | 05/11/2026 | Retiré le 09/11/2026 à la demande de Basile |

## Grille

État au 09/11/2026 : 76 points sur 104, soit 73 % de la cible. 4 couverts, 7 partiels, 1 amorcé, 1 non couvert.

| Domaine | Critère | Note | Assets retenus | Pourquoi cette note | Pour passer à ● |
|---|---|---|---|---|---|
| IM · Instruction métier | Connaître | ● | edfdco-moe-distill, bmad-agent-pm, Convention entrants, Convention relecture et suivi | MOE distillé, agent PM, conventions des entrants et de relecture : la connaissance métier est documentée | — |
| IM · Instruction métier | Produire | ● | edfdco-distill, edfdco-brief, edfdco-bpmn-to-prd, hrz-bmad-to-jira, bmad-product-brief, bmad-prd, bmad-create-epics-and-stories | Brief, distillation, BPMN vers PRD, PRD, epics et stories, synchronisation BMAD vers Jira | — |
| IM · Instruction métier | Accéder | ● | MCP Gateway EDF (contribue) | Jira et Confluence accessibles par la Gateway EDF | — |
| IM · Instruction métier | Contrôler | ● | edfdco-docreview, edfdco-project-checkpoint | Contrôle de cohérence PRD / architecture / epics, revue documentaire tracée | — |
| UX · Design / UX | Connaître | – | — | Aucun référentiel UX ni règle de parcours dans l'inventaire | Un référentiel UX : règles de parcours, composants |
| UX · Design / UX | Produire | ○ | edfdco-maquette-vers-lwc | La maquette vers LWC implémente une maquette existante ; rien pour la concevoir | Une skill de conception ou de reprise des maquettes |
| UX · Design / UX | Accéder | – | — | Aucun accès outillé aux maquettes | Un accès MCP aux maquettes (Figma ou équivalent) |
| UX · Design / UX | Contrôler | ● | edfdco-pdg-lwc-guard, edfdco-agent-wcag-auditor | Garde-fou UX des parcours guidés Canopée, audit d'accessibilité WCAG | — |
| AR · Architecture | Connaître | ● | edfdco-agent-data-architect, bmad-agent-architect, Référentiel de patterns d'intégration, Arbre de décision des patterns, Pratique Kafka vs IBM MQ, Convention avancement conception des flux, Convention diagrammes, Convention matrice événements × SI, Convention référentiel de connaissances EA | Patterns d'intégration, arbre de décision, conventions de diagrammes et de flux, référentiel EA, agents conseillers | — |
| AR · Architecture | Produire | ● | edfdco-da, edfdco-da-dca, edfdco-da-dca-officiel, edfdco-da-plaasma, edfdco-da-arom, edfdco-pattern-lifecycle, edfdco-archi-arbitrage, edfdco-archi-exporter, edfdco-archimate-flow-analyzer, edfdco-archimate-pattern-template-gen, edfdco-archimate-pattern-wizard, edfdco-archimate-product-gen, edfdco-cartographie-flux, edfdco-dossier-flux, edfdco-evenements-si, edfdco-diagram-gen, edfdco-tech-arch-designer, hrz-create-contrat-interface, edfdco-archi-to-bpmn (contribue), bmad-create-architecture | Pipeline DA/DCA, cycle de vie des patterns, ArchiMate, registre des flux, contrats d'interface | — |
| AR · Architecture | Accéder | ● | edfdco-leonard-sync-agent, MCP Gateway EDF (contribue) | Base de connaissance Léonard synchronisée, Confluence par la Gateway EDF | — |
| AR · Architecture | Contrôler | ● | edfdco-project-checkpoint (contribue), edfdco-agent-vitruve | Gardien du référentiel d'architecture (Vitruve), contrôle de cohérence projet | — |
| CA · SI Canopée | Connaître | ○ | Script init/fraîcheur miroir sf-main | Miroir du code sf-main et skills Salesforce génériques héritées d'ae-skills ; aucune convention propre à Canopée | Des conventions Canopée : modèle de données, orchestrateurs PDG, nommage |
| CA · SI Canopée | Produire | ● | sf-platform-*, sf-experience-*, sf-integration-* (suite héritée d'ae-skills), edfdco-maquette-vers-lwc (contribue), Script sync des skills ae-skills | 12 skills Salesforce, maquette vers LWC, synchronisation des skills ae-skills | — |
| CA · SI Canopée | Accéder | ● | MCP Copado Agentia | Copado Agentia : CI/CD, pipelines, CRT | — |
| CA · SI Canopée | Contrôler | ● | edfdco-pdg-lwc-guard (contribue), edfdco-crt-dev (contribue), edfdco-supervise-e2e (contribue), Hook Salesforce / Apex, Hook Agentia / Copado, Script hygiène données de test Apex | Hooks Apex et LWC, tests CRT, supervision de bout en bout, hygiène des données de test | — |
| PL · SI Plaasma | Connaître | ● | hrz-create-contrat-interface (contribue), Pratique OAuth2 Plaasma | Pratique OAuth2 Plaasma et normes de flux Horizon (API-Led, nomenclature) portées par la skill de contrat d'interface | — |
| PL · SI Plaasma | Produire | ○ | edfdco-da-plaasma (contribue), hrz-create-contrat-interface (contribue) | Contrat d'interface et dossier DA Plaasma ; aucune skill de développement MuleSoft dans l'inventaire (préfixe mulesoft-* vide) | Des skills de développement MuleSoft, ou l'intégration de celles publiées par MuleSoft le 17/09 ; plugin plaasma à confirmer |
| PL · SI Plaasma | Accéder | ● | MCP Jenkins, MCP CloudWatch (contribue) | Jenkins et CloudWatch ; Anypoint par le plugin plaasma | — |
| PL · SI Plaasma | Contrôler | ● | edfdco-supervise-e2e (contribue), Hook Plaasma, Hook Jenkins | Hook Plaasma avant écriture et gate de conformité, revalidation Jenkins avant déploiement, supervision de bout en bout | — |
| CM · SI Camunda | Connaître | – | — | Aucune pratique ni convention Camunda dans l'inventaire | Des conventions BPMN, FEEL et connecteurs |
| CM · SI Camunda | Produire | ○ | edfdco-archi-to-bpmn | Génération du processus BPMN depuis l'architecture ; rien pour les workers et connecteurs | Une skill de développement des workers et connecteurs |
| CM · SI Camunda | Accéder | ● | MCP Camunda | MCP Camunda : validation BPMN, webhooks, Operate | — |
| CM · SI Camunda | Contrôler | ● | edfdco-supervise-e2e (contribue), Hook Camunda | Hook Camunda : tests FEEL et validation BPMN avant déploiement ; supervision de bout en bout | — |
| FA · SI Facthori | Connaître | ● | edfdco-facthori-retrodocumentation, Pratique analyse de l'existant SAP | Rétro-documentation des processus SAP, méthode d'analyse de l'existant | — |
| FA · SI Facthori | Produire | ● | edfdco-facthori-odata-v2, edfdco-facthori-rfc-dev | Services OData V2, développement ABAP à distance | — |
| FA · SI Facthori | Accéder | ● | MCP SAP RFC | MCP SAP RFC | — |
| FA · SI Facthori | Contrôler | ● | Hook SAP, Script classification RFC SAP | Hook SAP avant et après écriture, classification des RFC | — |
| ED · SI Éditique | Connaître | – | — | Aucun asset ; premier contact avec l'Éditique le 03/11, refonte ROCK en pause | Une connaissance documentée des outils de l'Éditique |
| ED · SI Éditique | Produire | – | — | Aucun asset | Une skill de production des documents |
| ED · SI Éditique | Accéder | – | — | Aucun asset | Un accès outillé à l'Éditique |
| ED · SI Éditique | Contrôler | – | — | Aucun asset | Un contrôle des documents produits |
| TQ · Tests et qualité | Connaître | ● | Pratique « Ce qui vaut preuve », Pratique processus de développement assisté (contribue) | « Ce qui vaut preuve » (17 règles adossées à des incidents), définition de fini du développement assisté | — |
| TQ · Tests et qualité | Produire | ○ | edfdco-crt-dev | Tests CRT de bout en bout sur Canopée ; aucun générateur de tests de contrat inter-SI ni de non-régression transverse | Une génération de tests de contrat inter-SI |
| TQ · Tests et qualité | Accéder | ○ | MCP Copado Agentia (contribue), Script hygiène données de test Apex (contribue) | CRT par Copado, données de test Apex ; pas d'accès outillé aux jeux de données des autres SI | Un accès aux environnements et jeux de test des autres SI |
| TQ · Tests et qualité | Contrôler | ● | edfdco-supervise-e2e, bmad-code-review, Hook Agentia / Copado (contribue), Hook sonde jetable | Supervision de bout en bout PASS/FAIL, revue de code BMAD, garde-fous CRT | — |
| SE · Sécurité et conformité | Connaître | ● | edfdco-agent-data-governance, Pratique OAuth2 Plaasma (contribue), Pratique sécurité applicative OWASP | Pratique OWASP, agent de gouvernance des données et RGPD, OAuth2 | — |
| SE · Sécurité et conformité | Produire | ○ | edfdco-da-dca (contribue), edfdco-da-dca-officiel (contribue) | Dossiers DCA générés ; aucune production de mesures de sécurité | Une skill de mise en œuvre des mesures de sécurité |
| SE · Sécurité et conformité | Accéder | ○ | edfdco-openbao | OpenBao pour les secrets ; aucun accès aux outils de sécurité | Un accès aux outils de scan et de vulnérabilités |
| SE · Sécurité et conformité | Contrôler | – | — | Aucun contrôle de sécurité automatisé : l'analyse de failles par LLM public est classée C3 | Un contrôle par outil autorisé ou par modèle open-weight souverain |
| EX · Exploitation et MCO | Connaître | ○ | Pratique logs minimaux SPOT | Logs minimaux SPOT ; aucune procédure de MCO | Une procédure de MCO (question Q25) |
| EX · Exploitation et MCO | Produire | ● | edfdco-anomalie, logs-mini-skill | Instruction d'anomalie Jira, configuration des cohortes SPOT | — |
| EX · Exploitation et MCO | Accéder | ● | MCP Copado Agentia (contribue), MCP Jenkins (contribue), MCP CloudWatch, MCP Config Cohorte, MCP Elasticsearch, MCP Clark, MCP SSH SPOT | CloudWatch, Elasticsearch, SSH SPOT, Config Cohorte, Clark, Jenkins, Copado | — |
| EX · Exploitation et MCO | Contrôler | ● | Hook Camunda (contribue), Hook Salesforce / Apex (contribue), Hook Jenkins (contribue) | Contrôles avant déploiement Salesforce, Camunda et Jenkins | — |
| DB · Dépôt BMAD multi-équipes | Connaître | ○ | edfdco-guide-parcours (contribue), Convention OKF frontmatter | Convention OKF, guide de parcours ; arborescence et règles de partage non documentées | L'arborescence multi-projets et les règles de partage documentées |
| DB · Dépôt BMAD multi-équipes | Produire | ○ | bmad-create-story, Script détection projet BMAD actif | Détection du projet BMAD actif, configuration de create-story ; pas de skill de création de projet dans l'inventaire | Une skill de création de projet |
| DB · Dépôt BMAD multi-équipes | Accéder | ● | edfdco-habilitations (contribue), Script sync git, Script sync des skills ae-skills (contribue) | Synchronisation git, synchronisation des skills ae-skills, habilitations Git | — |
| DB · Dépôt BMAD multi-équipes | Contrôler | ○ | Convention hooks, Hook git-hooks / claude-hooks | Hooks réinstallés à chaque session, convention des hooks ; aucun contrôle de duplication du patrimoine partagé | Un contrôle de duplication et de propriété des assets partagés |
| MP · Méthode et pilotage | Connaître | ● | edfdco-guide-parcours, bmad-agent-dev, Pratique gouvernance SAFe, Pratique processus de développement assisté, Convention publication Confluence, Convention visuels de diapositive | Gouvernance SAFe, processus de développement assisté, conventions de publication, agent dev | — |
| MP · Méthode et pilotage | Produire | ● | edfdco-cockpit, edfdco-fill-pptx, edfdco-agent-session-handover, edfdco-habilitations, bmad-dev-story, Script check présences, Script status line connexions, Script maj date dashboard, Script chaîne de publication Confluence, Script convertisseurs Markdown/Mermaid | Cockpit, génération des supports, habilitations, passation entre sessions | — |
| MP · Méthode et pilotage | Accéder | ● | edfdco-mcp-jira-setup, MCP Gateway EDF, Script refresh token Gardian | Gateway EDF, configuration du MCP Jira, renouvellement du jeton Gardian | — |
| MP · Méthode et pilotage | Contrôler | ● | Hook Confluence, Script audit MCP, Script préflight connexions expirantes | Hook Confluence, audit des MCP, contrôle des connexions qui expirent | — |

## Assets

122 assets, 111 lignes : la suite Salesforce compte pour 12. Les 4 variantes historiques du pipeline DA/DCA sont comptées, comme dans l'inventaire. Les hooks sont détaillés en 9 groupes et les scripts un par un : l'inventaire du 05/11 annonçait ≈ 113 assets et ≈ 14 hooks, écart signalé dans la fiche 22.

Contributions : `CODE/Critère`, séparées par des virgules.

| Asset | Type | Nombre | Domaine | Critère | Contribue aussi à | Statut |
|---|---|---|---|---|---|---|
| bmad-agent-pm | Customisation BMAD | 1 | IM | Connaître | — | Actif |
| Convention entrants | Savoir | 1 | IM | Connaître | — | Actif |
| Convention relecture et suivi | Savoir | 1 | IM | Connaître | — | Actif |
| edfdco-moe-distill | Skill | 1 | IM | Connaître | — | Actif |
| bmad-create-epics-and-stories | Customisation BMAD | 1 | IM | Produire | — | Actif |
| bmad-prd | Customisation BMAD | 1 | IM | Produire | — | Actif |
| bmad-product-brief | Customisation BMAD | 1 | IM | Produire | — | Actif |
| edfdco-bpmn-to-prd | Skill | 1 | IM | Produire | — | Actif |
| edfdco-brief | Skill | 1 | IM | Produire | — | Actif |
| edfdco-distill | Skill | 1 | IM | Produire | — | Actif |
| hrz-bmad-to-jira | Skill | 1 | IM | Produire | — | Actif |
| edfdco-docreview | Skill | 1 | IM | Contrôler | — | Actif |
| edfdco-project-checkpoint | Skill | 1 | IM | Contrôler | AR/Contrôler | Actif |
| edfdco-maquette-vers-lwc | Skill | 1 | UX | Produire | CA/Produire | Actif |
| edfdco-agent-wcag-auditor | Skill | 1 | UX | Contrôler | — | Actif |
| edfdco-pdg-lwc-guard | Skill | 1 | UX | Contrôler | CA/Contrôler | Actif |
| bmad-agent-architect | Customisation BMAD | 1 | AR | Connaître | — | Actif |
| Arbre de décision des patterns | Savoir | 1 | AR | Connaître | — | Actif |
| Convention avancement conception des flux | Savoir | 1 | AR | Connaître | — | Actif |
| Convention diagrammes | Savoir | 1 | AR | Connaître | — | Actif |
| Convention matrice événements × SI | Savoir | 1 | AR | Connaître | — | Actif |
| Convention référentiel de connaissances EA | Savoir | 1 | AR | Connaître | — | Actif |
| Pratique Kafka vs IBM MQ | Savoir | 1 | AR | Connaître | — | Actif |
| Référentiel de patterns d'intégration | Savoir | 1 | AR | Connaître | — | Actif |
| edfdco-agent-data-architect | Skill | 1 | AR | Connaître | — | Actif |
| bmad-create-architecture | Customisation BMAD | 1 | AR | Produire | — | Actif |
| edfdco-archi-arbitrage | Skill | 1 | AR | Produire | — | Actif |
| edfdco-archi-exporter | Skill | 1 | AR | Produire | — | Actif |
| edfdco-archimate-flow-analyzer | Skill | 1 | AR | Produire | — | Actif |
| edfdco-archimate-pattern-template-gen | Skill | 1 | AR | Produire | — | Actif |
| edfdco-archimate-pattern-wizard | Skill | 1 | AR | Produire | — | Actif |
| edfdco-archimate-product-gen | Skill | 1 | AR | Produire | — | Actif |
| edfdco-cartographie-flux | Skill | 1 | AR | Produire | — | Actif |
| edfdco-da | Skill | 1 | AR | Produire | — | Actif |
| edfdco-da-arom | Skill | 1 | AR | Produire | — | Historique, remplacée par edfdco-da |
| edfdco-da-dca | Skill | 1 | AR | Produire | SE/Produire | Historique, remplacée par edfdco-da |
| edfdco-da-dca-officiel | Skill | 1 | AR | Produire | SE/Produire | Historique, remplacée par edfdco-da |
| edfdco-da-plaasma | Skill | 1 | AR | Produire | PL/Produire | Historique, remplacée par edfdco-da |
| edfdco-diagram-gen | Skill | 1 | AR | Produire | — | Actif |
| edfdco-dossier-flux | Skill | 1 | AR | Produire | — | Actif |
| edfdco-evenements-si | Skill | 1 | AR | Produire | — | Actif |
| edfdco-pattern-lifecycle | Skill | 1 | AR | Produire | — | Actif |
| edfdco-tech-arch-designer | Skill | 1 | AR | Produire | — | Actif |
| hrz-create-contrat-interface | Skill | 1 | AR | Produire | PL/Produire, PL/Connaître | Actif |
| edfdco-leonard-sync-agent | Skill | 1 | AR | Accéder | — | Actif |
| edfdco-agent-vitruve | Skill | 1 | AR | Contrôler | — | Actif |
| Script init/fraîcheur miroir sf-main | Script | 1 | CA | Connaître | — | Actif |
| Script sync des skills ae-skills | Script | 1 | CA | Produire | DB/Accéder | Actif |
| sf-platform-*, sf-experience-*, sf-integration-* (suite héritée d'ae-skills) | Skill | 12 | CA | Produire | — | Actif |
| MCP Copado Agentia | Serveur MCP | 1 | CA | Accéder | TQ/Accéder, EX/Accéder | Actif |
| Hook Agentia / Copado | Hook | 1 | CA | Contrôler | TQ/Contrôler | Actif |
| Hook Salesforce / Apex | Hook | 1 | CA | Contrôler | EX/Contrôler | Actif |
| Script hygiène données de test Apex | Script | 1 | CA | Contrôler | TQ/Accéder | Actif |
| Pratique OAuth2 Plaasma | Savoir | 1 | PL | Connaître | SE/Connaître | Actif |
| MCP Jenkins | Serveur MCP | 1 | PL | Accéder | EX/Accéder | Actif |
| Hook Jenkins | Hook | 1 | PL | Contrôler | EX/Contrôler | Actif |
| Hook Plaasma | Hook | 1 | PL | Contrôler | — | Actif |
| edfdco-archi-to-bpmn | Skill | 1 | CM | Produire | AR/Produire | Actif |
| MCP Camunda | Serveur MCP | 1 | CM | Accéder | — | Actif |
| Hook Camunda | Hook | 1 | CM | Contrôler | EX/Contrôler | Actif |
| Pratique analyse de l'existant SAP | Savoir | 1 | FA | Connaître | — | Actif |
| edfdco-facthori-retrodocumentation | Skill | 1 | FA | Connaître | — | Actif |
| edfdco-facthori-odata-v2 | Skill | 1 | FA | Produire | — | Actif |
| edfdco-facthori-rfc-dev | Skill | 1 | FA | Produire | — | Actif |
| MCP SAP RFC | Serveur MCP | 1 | FA | Accéder | — | Actif |
| Hook SAP | Hook | 1 | FA | Contrôler | — | Actif |
| Script classification RFC SAP | Script | 1 | FA | Contrôler | — | Actif |
| Pratique « Ce qui vaut preuve » | Savoir | 1 | TQ | Connaître | — | Actif |
| edfdco-crt-dev | Skill | 1 | TQ | Produire | CA/Contrôler | Actif |
| bmad-code-review | Customisation BMAD | 1 | TQ | Contrôler | — | Actif |
| Hook sonde jetable | Hook | 1 | TQ | Contrôler | — | Actif |
| edfdco-supervise-e2e | Skill | 1 | TQ | Contrôler | CA/Contrôler, PL/Contrôler, CM/Contrôler | Actif |
| Pratique sécurité applicative OWASP | Savoir | 1 | SE | Connaître | — | Actif |
| edfdco-agent-data-governance | Skill | 1 | SE | Connaître | — | Actif |
| edfdco-openbao | Skill | 1 | SE | Accéder | — | Actif |
| Pratique logs minimaux SPOT | Savoir | 1 | EX | Connaître | — | Actif |
| edfdco-anomalie | Skill | 1 | EX | Produire | — | Actif |
| logs-mini-skill | Skill | 1 | EX | Produire | — | Actif |
| MCP Clark | Serveur MCP | 1 | EX | Accéder | — | Actif |
| MCP CloudWatch | Serveur MCP | 1 | EX | Accéder | PL/Accéder | Actif |
| MCP Config Cohorte | Serveur MCP | 1 | EX | Accéder | — | Actif |
| MCP Elasticsearch | Serveur MCP | 1 | EX | Accéder | — | Actif |
| MCP SSH SPOT | Serveur MCP | 1 | EX | Accéder | — | Actif |
| Convention OKF frontmatter | Savoir | 1 | DB | Connaître | — | Actif |
| bmad-create-story | Customisation BMAD | 1 | DB | Produire | — | Actif |
| Script détection projet BMAD actif | Script | 1 | DB | Produire | — | Actif |
| Script sync git | Script | 1 | DB | Accéder | — | Actif |
| Hook git-hooks / claude-hooks | Hook | 1 | DB | Contrôler | — | Actif |
| Convention hooks | Savoir | 1 | DB | Contrôler | — | Actif |
| bmad-agent-dev | Customisation BMAD | 1 | MP | Connaître | — | Actif |
| Convention publication Confluence | Savoir | 1 | MP | Connaître | — | Actif |
| Convention visuels de diapositive | Savoir | 1 | MP | Connaître | — | Actif |
| Pratique gouvernance SAFe | Savoir | 1 | MP | Connaître | — | Actif |
| Pratique processus de développement assisté | Savoir | 1 | MP | Connaître | TQ/Connaître | Actif |
| edfdco-guide-parcours | Skill | 1 | MP | Connaître | DB/Connaître | Actif |
| bmad-dev-story | Customisation BMAD | 1 | MP | Produire | — | Actif |
| Script chaîne de publication Confluence | Script | 1 | MP | Produire | — | Actif |
| Script check présences | Script | 1 | MP | Produire | — | Actif |
| Script convertisseurs Markdown/Mermaid | Script | 1 | MP | Produire | — | Actif |
| Script maj date dashboard | Script | 1 | MP | Produire | — | Actif |
| Script status line connexions | Script | 1 | MP | Produire | — | Actif |
| edfdco-agent-session-handover | Skill | 1 | MP | Produire | — | Actif |
| edfdco-cockpit | Skill | 1 | MP | Produire | — | Actif |
| edfdco-fill-pptx | Skill | 1 | MP | Produire | — | Actif |
| edfdco-habilitations | Skill | 1 | MP | Produire | DB/Accéder | Actif |
| Script refresh token Gardian | Script | 1 | MP | Accéder | — | Actif |
| MCP Gateway EDF | Serveur MCP | 1 | MP | Accéder | IM/Accéder, AR/Accéder | Actif |
| edfdco-mcp-jira-setup | Skill | 1 | MP | Accéder | — | Actif |
| Hook Confluence | Hook | 1 | MP | Contrôler | — | Actif |
| Script audit MCP | Script | 1 | MP | Contrôler | — | Actif |
| Script préflight connexions expirantes | Script | 1 | MP | Contrôler | — | Actif |

## Plan d'action

Rempli chaque semaine par l'équipe, repris dans le cadre « Plan d'action » de la planche, cinq lignes au plus. Laisser la table vide pour que l'équipe complète le cadre directement dans PowerPoint.

| # | Action | Porteur | Échéance | Statut |
|---|---|---|---|---|

## Historique

Une ligne par édition. Scores : `CODE points`, séparés par des points médians, pour comparer les éditions à périmètre constant.

| Édition | Domaines suivis | Points | Cible | Progression | Couverts | Partiels | Amorcés | Non couverts | Scores | Événement |
|---|---|---|---|---|---|---|---|---|---|---|
| 05/11/2026 | 14 | 78 | 112 | 70 % | 4 | 7 | 2 | 1 | IM 8 · UX 3 · DG 2 · AR 8 · CA 7 · PL 7 · CM 5 · FA 8 · ED 0 · TQ 6 · SE 4 · EX 7 · DB 5 · MP 8 | Première mesure, inventaire du 05/11 |
| 09/11/2026 | 13 | 76 | 104 | 73 % | 4 | 7 | 1 | 1 | IM 8 · UX 3 · AR 8 · CA 7 · PL 7 · CM 5 · FA 8 · ED 0 · TQ 6 · SE 4 · EX 7 · DB 5 · MP 8 | Digital retiré du suivi. Pas de nouvel inventaire : à périmètre constant, aucune évolution depuis le 05/11 |
