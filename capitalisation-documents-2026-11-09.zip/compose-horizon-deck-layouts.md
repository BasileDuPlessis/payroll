# Mises en page du template Horizon 2026

Template : `templates/Template Horizon 2026 05-01-26.pptx`, 16:9, 13,333 × 7,5 pouces. Un masque unique, 26 mises en page. Inventaire du 05/11/2026.

Les clés d'espace réservé s'utilisent dans `ph` de `deck.slide()`. `title` désigne l'espace réservé de type titre (`title` ou `ctrTitle`) et `subTitle` le sous-titre ; un nombre désigne l'`idx` d'un espace réservé de corps. Les positions sont en pouces.

## Mises en page couvertes par une méthode de `horizon.js`

| Méthode | Mise en page | Espaces réservés | Usage |
|---|---|---|---|
| `cover()` | Diapositive de titre | `11` titre (0,40 ; 2,62 · 5,52 × 2,24), `12` sous-titre, `13` date | Couverture, photo à droite. Variantes de photo : 1_, 2_, 3_, 4_, 6_ et 7_Diapositive de titre |
| `section()` | Titre et sous titre de la partie | `title` (0,48 ; 2,60 · 8,08 × 2,12), `subTitle`, `12` numéro « 01 » | Intercalaire |
| `content()` | Titre et contenu | `title` (0 ; 0 · 12,93 × 1,50, Work Sans Light 32 pt, bleu `1089FF`), `14` corps (0,50 ; 1,76 · 12,24 × 4,86) | Planche de texte à puces |
| `free()` | Titre et contenu | `title` seul ; la zone de corps est remplacée par des formes libres | Tableau de bord, schéma, mise en page sur mesure |
| `columns(2)` | 2 colonnes | `title`, `18`/`20` en-tête et corps de la colonne de gauche, `22`/`21` de la colonne de droite | Comparaison |
| `columns(3)` | 3 colonnes | `title`, puis en-tête et corps par colonne : `20`/`21`, `22`/`23`, `24`/`25` | Trois blocs |
| `columns(4)` | 4 colonnes | `title`, puis en-tête et corps par colonne : `22`/`23`, `24`/`25`, `26`/`27`, `28`/`29` | Quatre blocs |
| `quote()` | Citation_full | `title` pour la citation, `10` pour l'auteur | Citation pleine page |
| `end()` | Slide de fin | aucun | Planche « Merci » |

## Autres mises en page, accessibles par `deck.slide(nom, ph)`

| Mise en page | Espaces réservés |
|---|---|
| Sommaire 1 colonne | `title`, `13` à `18`, une entrée chacun (6,10 ; 0,53 puis tous les 1,06) |
| Sommaire 2 colonnes | `title`, `13` à `16` pour la colonne de gauche, `17` à `20` pour la colonne de droite |
| Titre et contenu surtitre | `15` surtitre en capitales, `title`, `14` corps |
| Split 2 parties | `title`, `20` en-tête, `21` corps, moitié gauche de la planche |
| Split 2 parties et surtitre | `15`, `title`, `22`, `23` |
| Split 2 parties image | `14` image (moitié droite), `title`, `20`, `21` |
| Split image statistique | `14` image, `title`, `20` chiffre, `21` unité, `19` texte |
| Citation_50, Citation_66 | `title` pour la citation, `10` pour l'auteur |
| Statistiques couleurs | `20`/`21`/`22` premier chiffre, unité et libellé ; `23`/`24`/`25` second ; `18` et `26` corps |
| Charte éthique du Groupe | `title` |

Les espaces réservés d'image (`pic`) ne se remplissent pas par `ph`. Pour une image, dessinez-la en forme libre avec `s.addImage(...)` dans `free()` : la greffe copie les médias.

## Masque, commun à toutes les mises en page

- Logo EDF en bas à gauche : 0,30 ; 6,54, sur 1,45 × 0,96.
- Logo Horizon en bas à droite : 11,25 ; 6,73, sur 1,70 × 0,72.
- Numéro de page : 10,77 ; 6,96.

Rien ne doit déborder sous 6,46 pouces, sauf entre les deux logos, de 2,0 à 10,6 en largeur.

Thème : `001A70` marine, `1057C8` bleu, `1089FF` bleu clair des titres, `FE5716` orange, `FF861D` orange clair, `FFB210` ambre. Polices : Work Sans, Work Sans SemiBold, Work Sans Light pour les titres.
