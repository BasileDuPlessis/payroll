# Prompt : tenir à jour chaque semaine le tableau de bord de la capitalisation

Prompt à donner à une session Claude Code ouverte dans le dépôt de la mission. Préparé le 09/11/2026. Il remplace [`22-prompt-adaptation-skill-pcv.md`](22-prompt-adaptation-skill-pcv.md) du 05/11. Tout ce qui suit la ligne se copie tel quel.

---

## Ta mission

Tu tiens à jour, chaque semaine, la planche « Tableau de bord de la capitalisation agentique ». Le management la revoit chaque semaine. Elle montre où en est la capitalisation des assets agentiques de l'équipe (skills, customisations BMAD, hooks, scripts, serveurs MCP, pratiques, conventions, patterns) par rapport à une cible.

Tu prépares la mise à jour. Basile, ou le référent qu'il désigne, valide toute note de la grille avant publication. Tu ne rédiges jamais le plan d'action à la place de l'équipe.

## Fichiers

| Rôle | Chemin |
|---|---|
| Source de vérité : domaines, grille justifiée, affectation des assets, plan d'action, historique | `synthese/22-capitalisation-affectation-assets.md` |
| Planche publiée, version courante | `synthese/22-tableau-de-bord-capitalisation.pptx`, aperçu `synthese/22-tableau-de-bord-capitalisation.png` |
| Contexte, règles et écarts de comptage connus | `synthese/22-tableau-de-bord-capitalisation.md` |
| Script de la planche : il lit la source de vérité, contrôle sa cohérence et dessine | `synthese/22-tableau-de-bord-capitalisation-deck.js` |
| Skill de production des présentations : greffe sur le template, vérification | `.claude/skills/compose-horizon-deck/` ; lire son `SKILL.md` |
| Template | `templates/Template Horizon 2026 05-01-26.pptx` |

Le script est versionné dans le dépôt avec la table qu'il lit. Les fichiers qu'il produit restent hors du dépôt, dans `~/.cache/horizon-deck/capitalisation/` : seule la planche finale est copiée dans `synthese/`. Une évolution de la planche se fait dans ce script. Vérifie ensuite que la planche publiée est inchangée là où rien ne devait bouger.

## La planche

Elle a été retenue le 09/11 : c'est la variante A, sans le Digital, avec un cadre « Plan d'action » à la place du texte de droite. De haut en bas :
- **titre calculé :** « Capitalisation agentique : {x} % de la cible atteinte, {n} domaines sur {N} couverts » ;
- **bandeau de pitch ;**
- **bande « Les 4 critères »,** avec leurs définitions et la case « Lecture » (● outillé, ○ partiel, – absent) ;
- **à gauche, la grille :** les domaines groupés par famille, une marque par critère, la pastille d'état ;
- **à droite, la progression vers la cible :** le pourcentage et sa jauge, les points sur la cible, le décompte des états, puis l'évolution à périmètre constant depuis l'édition précédente ;
- **dessous, le cadre « Plan d'action » :** il porte « Semaine du jj/mm/aaaa » et accueille au plus cinq actions de la table Plan d'action. Si la table est vide, il reste vide pour que l'équipe le remplisse dans PowerPoint ;
- **en bas, le bandeau « Amélioration continue ».**

La hauteur des lignes de la grille s'ajuste au nombre de domaines. Seize domaines tiennent sur la planche. Au-delà de dix-huit, le script prévient : il faudra envisager deux planches.

## Règles de notation

Elles sont rappelées en tête de la source de vérité.
- **Notes d'une case :** ● = 2, ○ = 1, – = 0.
- **États d'un domaine,** sur 8 points : Couvert = 8 ; Partiel = de 4 à 7 ; Amorcé = de 1 à 3 ; Non couvert = 0.
- **Cible :** 8 points par domaine suivi. Progression = points ÷ cible.
- **Cohérence :** une note supérieure à 0 exige au moins un asset dans la case, en domaine principal ou en contribution ; une note de 0 n'en admet aucun.

Le script refuse de générer la planche tant qu'une incohérence subsiste.

## Procédure hebdomadaire

1. **Récupérer l'inventaire de la semaine.** C'est l'export des assets du dépôt de l'équipe, celui qui porte les skills `edfdco-*`, au format de celui du 05/11. Si tu n'y as pas accès, demande-le à Basile. Pas d'inventaire nouveau signifie pas de changement d'assets : dis-le.
2. **Comparer avec la table Assets.** Liste les assets nouveaux, disparus et renommés. Pour chaque nouvel asset, propose un domaine principal, un critère et des contributions, avec une phrase de justification. Les fichiers `.toml` de `_bmad/custom/` sont des assets : le script de comptage du PCV les ignore à tort.
3. **Proposer les changements de note.** Pour chaque case touchée, rédige la nouvelle justification (« Pourquoi cette note ») et ce qui manque (« Pour passer à ● »). Présente les propositions sous forme de tableau et attends la validation avant d'écrire dans la grille. Une note ne monte que si un asset de l'inventaire le justifie.
4. **Demander le plan d'action** à l'équipe, par Basile : actions, porteurs, échéances, statuts. Reporte-le tel quel dans la table Plan d'action. Si l'équipe préfère remplir le cadre directement dans PowerPoint, laisse la table vide.
5. **Mettre à jour l'édition** : la ligne « Édition en cours : jj/mm/aaaa ».
6. **Générer et vérifier :**
   ```
   W=~/.cache/horizon-deck/capitalisation; S=.claude/skills/compose-horizon-deck/scripts
   node synthese/22-tableau-de-bord-capitalisation-deck.js synthese/22-capitalisation-affectation-assets.md $W/out/deck
   python3 -I $S/graft.py "templates/Template Horizon 2026 05-01-26.pptx" $W/out/deck.pptx $W/out/deck.json $W/out/capitalisation.pptx
   $S/verify.sh $W/out/capitalisation.pptx $W/verif
   ```
   Lis l'image produite et vérifie qu'aucun texte ne déborde, qu'aucun bloc n'en chevauche un autre et que rien n'empiète sur la zone des logos.
7. **Ajouter la ligne d'historique.** Le script la propose ; complète la colonne « Événement » en une phrase factuelle.
8. **Publier dans le dépôt :** copier la planche dans `synthese/22-tableau-de-bord-capitalisation.pptx` et l'image dans `.png`. Le jour où la planche est transmise à EDF, déposer aussi une copie figée sous `livrables/YYYY-MM-DD-tableau-de-bord-capitalisation.pptx` et ajouter sa ligne à `livrables/README.md`. Ne commiter que sur demande, directement sur `main`.
9. **Rendre compte à Basile,** en quelques lignes : assets ajoutés ou retirés, notes changées et pourquoi, évolution à périmètre constant, points en attente de validation.

## Ajouter un SI, après l'Éditique

D'autres SI vont entrer dans le suivi. Pour chacun :
- une ligne dans Domaines, famille « Architecture et SI », placée juste après le dernier SI, avec un code de deux lettres et la date d'entrée ;
- quatre lignes dans Grille, notées – avec leur justification ;
- l'affectation de ses assets éventuels ;
- dans l'historique, la mention « SI X ajouté au suivi, cible +8 points ».

Le pourcentage baisse mécaniquement quand la cible s'élargit. La planche affiche l'évolution à périmètre constant pour ne pas confondre une baisse de périmètre avec un recul. Dis-le explicitement dans ton compte rendu.

Retirer un domaine suit la même logique, comme pour le Digital le 09/11 : son statut passe à « Retiré le … », ses lignes de Grille sont supprimées, ses assets sont réaffectés.

## À ne pas faire

- Ne modifie ni la liste des domaines ni les définitions des critères sans demande explicite.
- Ne monte aucune note sans asset qui la justifie, et ne valide aucune note toi-même.
- N'écris rien dans le plan d'action à la place de l'équipe.
- Ne présente pas le pourcentage comme une mesure de valeur métier : il mesure une couverture outillée.
- Ne retire pas l'étiquette de sensibilité EDF « C1 Interne » héritée du template.
- Si un envoi par mail échoue, lis la section « Error Details » du message de non-remise avant de soupçonner le fichier.

## Repères au 09/11/2026

76 points sur 104, soit 73 % de la cible : 4 domaines couverts, 7 partiels, 1 amorcé (Design / UX) et 1 non couvert (SI Éditique). Inventaire de référence du 05/11. Le Digital a été retiré du suivi le 09/11 à la demande de Basile ; à périmètre constant, rien n'a bougé depuis le 05/11.
